﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CRMConnectUtilities
{
    public static class Data
    {

        /// <summary>
        /// GetApiConfigurations
        /// </summary>
        /// <param name="service"></param>
        /// <param name="objSchemaMappingClass"></param>
        /// <returns>List<dynamic></returns>
        public static EntityCollection GetApiConfigurations(IOrganizationService service, object objSchemaMappingClass)
        {
            try
            {
                var query = new QueryExpression("mah_crmfoapiintegrationsetting");
                query.ColumnSet = new ColumnSet();
                List<ApiConfigSettings> ObjList = new List<ApiConfigSettings>();
                PropertyInfo[] ClasProperties = objSchemaMappingClass.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    if (Attribute.GetCustomAttributesData().Count > 0)
                    {
                        var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                        if (EntityAttributeCollection.Count > 0)
                        {
                            AttributeName = "" + EntityAttributeCollection[0].Value;
                        }
                    }
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                EntityCollection ec = service.RetrieveMultiple(query);
                return ec;
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        /// <summary>
        /// GetCrmEntityValueFromAnyJsonModel
        /// </summary>
        /// <param name="service"></param>
        /// <param name="JsonModel"></param>
        /// <returns>JToken</returns>
        public static JToken GetCrmEntityValueFromAnyJsonModel(
            IOrganizationService service, 
            string JsonModel
           )
        {
            JObject JsonParent = JObject.Parse(JsonModel);
            QueryExpression query = new QueryExpression();
            List<DynamicJsonClass> EntityAttributeList = new List<DynamicJsonClass>();
            List<DynamicJsonClass> LinkedEntityAttributeList = new List<DynamicJsonClass>();
            EntityCollection EntityWithValueCollection = new EntityCollection();
            foreach (JToken JsonChild in JsonParent.Children())
            {
               string KeyName = ((JProperty)JsonChild).Name;
                JToken objKeyValue = ((JProperty)JsonChild).Value;
                if(KeyName.Equals("entity", StringComparison.CurrentCultureIgnoreCase))
                {
                    query.EntityName = "" + objKeyValue;
                }
                if (KeyName.StartsWith("filter", StringComparison.CurrentCultureIgnoreCase))
                {
                   string[] ArrFilter = ("" + objKeyValue).Split(
                       new string[] {"=", "<>"},
                       StringSplitOptions.RemoveEmptyEntries
                       );
                    if (ArrFilter.Length > 0)
                    {
                        string FilterAttributeName = ArrFilter[0];
                        string FilterAttributeValue = ArrFilter[1];
                        ConditionOperator _Operator = new ConditionOperator();
                        if (("" + objKeyValue).Contains("="))
                        {
                            _Operator = ConditionOperator.Equal;
                        }
                        if (("" + objKeyValue).Contains("<>"))
                        {
                            _Operator = ConditionOperator.NotEqual;
                        }
                        query.Criteria.AddCondition(FilterAttributeName, _Operator, FilterAttributeValue);
                    }
                }

                foreach (JToken FieldKeyValue in objKeyValue)
                {
                    DynamicJsonClass objDynamicJsonModel = new DynamicJsonClass();
                    string FieldUserName = ((JProperty)FieldKeyValue).Name;
                    string EntityAttributeCollection = "" + ((JProperty)FieldKeyValue).Value;
                    if (EntityAttributeCollection.StartsWith("Value=", StringComparison.CurrentCultureIgnoreCase))
                    {
                        string _AttributeValue = EntityAttributeCollection.Replace("Value=", "");
                        Entity EntityWithValue = new Entity(query.EntityName);
                        EntityWithValue.Attributes.Add(FieldUserName, _AttributeValue);
                        EntityWithValueCollection.Entities.Add(EntityWithValue);
                        objDynamicJsonModel.FieldUserName = FieldUserName;
                        objDynamicJsonModel.EntityAttributeName = FieldUserName;
                        EntityAttributeList.Add(objDynamicJsonModel);
                        continue;
                    }
                    string[] ArrEntityAttributeCollection = EntityAttributeCollection.Split(
                             new string[] {".", "{", "=", "}" }, StringSplitOptions.RemoveEmptyEntries);
                    // 'CityID': 'mah_city.mah_cityid(ID)|account.mah_city'                    
                    objDynamicJsonModel.FieldUserName = FieldUserName;
                    objDynamicJsonModel.IdValueOnly = EntityAttributeCollection.ToUpper().Contains("(ID)") ? true : false;
                    if (ArrEntityAttributeCollection.Length >= 6)
                    {
                        objDynamicJsonModel.LinkedEntityName = ArrEntityAttributeCollection[0].Trim();
                        objDynamicJsonModel.EntityAttributeName =
                                                    objDynamicJsonModel.LinkedEntityName + "." +
                                                    ArrEntityAttributeCollection[1].Replace("(ID)", "").Trim();
                        objDynamicJsonModel.LinkedEntityAttributeName = ArrEntityAttributeCollection[3].Trim();
                        objDynamicJsonModel.ParentEntityName = ArrEntityAttributeCollection[4].Trim();
                        objDynamicJsonModel.ParentEntityAttributeName = ArrEntityAttributeCollection[5].Trim();
                        LinkedEntityAttributeList.Add(objDynamicJsonModel);
                    }
                    else if(ArrEntityAttributeCollection.Length == 1)
                    {
                        objDynamicJsonModel.EntityAttributeName = EntityAttributeCollection.Replace("(ID)", "").Trim();
                        query.ColumnSet.AddColumn(objDynamicJsonModel.EntityAttributeName);
                        EntityAttributeList.Add(objDynamicJsonModel);
                    }
                }

                foreach(DynamicJsonClass LinkedEntityAttribute in LinkedEntityAttributeList)
                {
                    bool _IsLinkedEntityExists = false;
                    string ColumnToGetValue = LinkedEntityAttribute.EntityAttributeName;
                    ColumnToGetValue = ColumnToGetValue.Replace(LinkedEntityAttribute.LinkedEntityName + ".", "");
                    foreach (LinkEntity _linkedEntity in query.LinkEntities)
                    {
                       if( _linkedEntity.LinkFromEntityName == LinkedEntityAttribute.ParentEntityName
                            && _linkedEntity.LinkToEntityName == LinkedEntityAttribute.LinkedEntityName)
                        {
                            _IsLinkedEntityExists = true;
                            if(!_linkedEntity.Columns.Columns.Contains(ColumnToGetValue))
                            {
                                _linkedEntity.Columns.AddColumn(ColumnToGetValue);
                            }
                        }
                    }
                    if (!_IsLinkedEntityExists)
                    {
                        LinkEntity _NewlinkEntity = new LinkEntity(
                                    LinkedEntityAttribute.ParentEntityName,
                                    LinkedEntityAttribute.LinkedEntityName,
                                    LinkedEntityAttribute.ParentEntityAttributeName,
                                    LinkedEntityAttribute.LinkedEntityAttributeName,
                                    JoinOperator.LeftOuter
                                    );
                        _NewlinkEntity.EntityAlias =  LinkedEntityAttribute.LinkedEntityName;
                        _NewlinkEntity.Columns.AddColumn(ColumnToGetValue);
                        query.LinkEntities.Add(_NewlinkEntity);                 
                    }                    
                }                
            }

            EntityCollection EntityResult = service.RetrieveMultiple(query);

            foreach (Entity _ResultEntity  in EntityResult.Entities)
            {
                foreach (Entity _ValueEntity in EntityWithValueCollection.Entities)
                {
                    foreach(var _Attribute in _ValueEntity.Attributes)
                    {
                        _ResultEntity.Attributes.Add(_Attribute);
                    }
                }
            }

            EntityAttributeList.AddRange(LinkedEntityAttributeList);

            JToken JSON_Output = Utilities.GetDynamicJsonArrayFromFetchXML(EntityResult, EntityAttributeList);

            return JSON_Output;
        }


        /*
            try
            {
                var query = new QueryExpression("account");
                query.ColumnSet = new ColumnSet();
                // Account _OutputDataModel = new Account();
                PropertyInfo[] ClasProperties = _OutputDataModel.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    if (Attribute.GetCustomAttributesData().Count > 0)
                    {
                        var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                        if (EntityAttributeCollection.Count > 0)
                        {
                            AttributeName = "" + EntityAttributeCollection[0].Value;
                        }
                    }
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("accountid", ConditionOperator.Equal, AccountId);
                EntityCollection ec = service.RetrieveMultiple(query);
                string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel);
                return JSON_Output;
            }
            catch (Exception ex)
            {

            }
            return "";
        }
        */
        /// <summary>
        /// JsonGetContact
        /// </summary>
        /// <param name="service"></param>
        /// <param name="AccountId"></param>
        /// <param name="ContactID"></param>
        /// <param name="objSchemaMappingClass"></param>
        /// <returns>Json String</returns>
        public static string JsonGetContact(IOrganizationService service, Guid AccountId)
        {
            try
            {
                var query = new QueryExpression("contact");
                query.ColumnSet = new ColumnSet();
                Contact _OutputDataModel = new Contact();
                PropertyInfo[] ClasProperties = _OutputDataModel.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    if (Attribute.GetCustomAttributesData().Count > 0)
                    {
                        var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                        if (EntityAttributeCollection.Count > 0)
                        {
                            AttributeName = "" + EntityAttributeCollection[0].Value;
                        }
                    }
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("parentcustomerid", ConditionOperator.Equal, AccountId);

                //query.Criteria.AddCondition("contactid", ConditionOperator.Equal, ContactID);

                //query.LinkEntities.Add(new LinkEntity("contact", "account", "primarycontactid", "contactid", JoinOperator.Inner));
                //query.LinkEntities[0].EntityAlias = "Acct";

                EntityCollection ec = service.RetrieveMultiple(query);
                string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel);
                return JSON_Output;
            }
            catch (Exception ex)
            {

            }
            return "";
        }

        /// <summary>
        /// JsonGetQuote
        /// </summary>
        /// <param name="service"></param>
        /// <param name="QuoteID"></param>
        /// <returns></returns>
        public static string JsonGetQuote(IOrganizationService service, Guid QuoteID, ref Quote _OutputDataModel)
        {
            try
            {
                var query = new QueryExpression("quote");
                query.ColumnSet = new ColumnSet();
                PropertyInfo[] ClasProperties = _OutputDataModel.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    if (Attribute.GetCustomAttributesData().Count > 0)
                    {
                        var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                        if (EntityAttributeCollection.Count > 0)
                        {
                            AttributeName = "" + EntityAttributeCollection[0].Value;
                        }
                    }
                    if (!AttributeName.Contains("."))
                    {
                        query.ColumnSet.Columns.Add(AttributeName);
                    }
                }
                //LinkEntity _businessunit = new LinkEntity("quote", "businessunit", "owningbusinessunit", "businessunitid", JoinOperator.Inner);
                //_businessunit.EntityAlias = "bu";
                //_businessunit.Columns.AddColumn("mk_legalentity");
                //query.LinkEntities.Add(_businessunit);




                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, QuoteID);

                query.LinkEntities.Add(new LinkEntity("quote", "businessunit", "owningbusinessunit", "businessunitid", JoinOperator.Inner));
                query.LinkEntities[0].Columns.AddColumns("mk_legalentity");
                query.LinkEntities[0].EntityAlias = "bu";


                EntityCollection ec = service.RetrieveMultiple(query);
                string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel);
                return JSON_Output;
            }
            catch (Exception ex)
            {

            }
            return "";
        }

        /// <summary>
        /// JsonGetQuoteDetail
        /// </summary>
        /// <param name="service"></param>
        /// <param name="QuoteID"></param>
        /// <returns></returns>
        public static string JsonGetQuoteDetail(IOrganizationService service, Guid QuoteID)
        {
            try
            {
                var query = new QueryExpression("quotedetail");
                query.ColumnSet = new ColumnSet();
                QuoteDetail _OutputDataModel = new QuoteDetail();
                PropertyInfo[] ClasProperties = _OutputDataModel.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    if (Attribute.GetCustomAttributesData().Count > 0)
                    {
                        var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                        if (EntityAttributeCollection.Count > 0)
                        {
                            AttributeName = "" + EntityAttributeCollection[0].Value;
                        }
                    }
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, QuoteID);
                EntityCollection ec = service.RetrieveMultiple(query);
                string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel);
                return JSON_Output;
            }
            catch (Exception ex)
            {

            }
            return "";
        }

    }
}
