﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRMConnectUtilities
{

    public class DynamicJsonClass
    {
        public string FieldUserName { get; set; }
        public string EntityAttributeName { get; set; }
        public string LinkedEntityName { get; set; }
        public string LinkedEntityAttributeName { get; set; }
        public string ParentEntityName { get; set; }
        public string ParentEntityAttributeName { get; set; }
        public bool IdValueOnly { get; set; }
    }

    public class DynamicJsonModel
    {
        public static readonly string _AccountCustomersJsonModel =
        @"{
          'entity': 'account',
          'filter': 'accountid={0}',
          'fields':  
             {               
                'dataAreaId':'Value={1}',
                'OrganizationName':'name',
                'CustomerAccount':'mah_customerid',
                'CustomerGroupId':'mah_customergroup',
                'SalesCurrencyCode':'transactioncurrency.isocurrencycode {transactioncurrency.transactioncurrencyid = quote.transactioncurrencyid}',
                'NameAlias':'name',
                'AddressStreet':'address1_line1',
                'AddressCity':'mah_city.mah_name {mah_city.mah_cityid = account.mah_city}',
                'AddressState':'mah_state.mah_name {mah_state.mah_stateid = account.mah_state}',
                'AddressZipCode':'mah_pincode.mah_name {mah_pincode.mah_pincodeid = account.mah_pincode}',
                'AddressCountryRegionId':'mah_country.mah_name {mah_country.mah_countryid = account.mah_country}',
                'AddressDescription':'name',
                'PrimaryContactEmailDescription':'Value=',
                'PrimaryContactEmail':'emailaddress1',
                'PrimaryContactPhone':'telephone1',
                'PaymentTerms':'paymenttermscode',
                'OnHoldStatus':'mah_customerhold',
                'PWC_RelationshipType': 'customertypecode',
                'PWC_Owener':'ownerid'
             }
         }";

        public static readonly string _ContactPesronJsonModel = @"{
          'entity': 'contact',
          'filter': 'parentcustomerid={0}',
          'fields':  
             {
                'dataAreaId': 'Value={1}',                
                'AssociatedPartyNumber': 'Value={2}',               
                'FirstName': 'firstname',
                'Gender': 'gendercode',
                'KnownAsName': 'fullname',
                'LastName': 'lastname',
                'MiddleName': 'middlename',
                'PrimaryEmailAddress': 'emailaddress1',
                'PrimaryEmailAddressDescription': 'fullname',
                'PrimaryEmailAddressPurpose': 'Value=',
                'PrimaryFacebook': 'Value=',
                'PrimaryFacebookDescription': 'Value=',
                'PrimaryFacebookPurpose': 'Value=',
                'PrimaryFaxNumber': 'Value=',
                'PrimaryFaxNumberDescription': 'Value=',
                'PrimaryFaxNumberExtension': 'Value=',
                'PrimaryFaxNumberPurpose': 'Value=',
                'PrimaryLinkedIn': 'Value=',
                'PrimaryLinkedInDescription': 'Value=',
                'PrimaryLinkedInPurpose': 'Value=',
                'PrimaryPhoneNumber': 'telephone1',
                'PrimaryPhoneNumberDescription': 'fullname',
                'PrimaryPhoneNumberExtension': 'Value=',
                'PrimaryPhoneNumberPurpose': 'Value=',
                'PrimarySalutationPhrase': 'salutation',
                'PrimaryTelex': 'Value=',
                'PrimaryTelexDescription': 'Value=',
                'PrimaryTelexPurpose': 'Value=',
                'PrimaryTwitter': 'Value=',
                'PrimaryTwitterDescription': 'Value=',
                'PrimaryTwitterPurpose': 'Value=',
                'PrimaryURL': 'Value=',
                'PrimaryURLDescription': 'Value=',
                'PrimaryURLPurpose': 'Value=',
                'SearchName': 'fullname'
             }
         }";
            
         

        public static readonly string _QuoteSalesJsonModel =
        @"{
          'entity': 'quote',
          'filter': 'quoteid={0}',
          'fields':  
             {
                'dataAreaId': 'Value={1}',
                'SalesQuotationNumber': 'mah_quotationnumber',
                'QuotationTakerPersonnelNumber': 'ownerid',
                'LanguageId': 'Value=en-us',
                'Email': 'systemuser.personalemailaddress {systemuser.systemuserid = quote.owninguser}',
                'OpportunityId': 'opportunityid',
                'RequestingCustomerAccountNumber': 'customerid',
                'CurrencyCode': 'transactioncurrency.isocurrencycode {transactioncurrency.transactioncurrencyid = quote.transactioncurrencyid}',  
                'PaymentTermsName': 'mah_paymentterms',
                'TotalDiscountPercentage': 'discountpercentage',
                'PWC_LPOAmount': 'Value=0',
                'PWC_LPODate': 'Value=',
                'DeliveryAddressName': 'account.name {account.accountid = quote.accountid}',
                'DeliveryAddressStreet': 'account.address1_line1 {account.accountid = quote.accountid}',
                'DeliveryAddressCity': 'account.mah_city {account.accountid = quote.accountid}',  
                'DeliveryAddressStateId': 'account.mah_state {account.accountid = quote.accountid}',
                'DeliveryAddressZipCode': 'account.mah_pincode {account.accountid = quote.accountid}',
                'DeliveryAddressCountryRegionId': 'account.mah_country {account.accountid = quote.accountid}',
                'DeliveryAddressDescription': 'account.name {account.accountid = quote.accountid}'
             }
         }";

        public static readonly string _QuoteProductSalesJsonModel =
        @"{
          'entity': 'quote',
          'filter': 'quoteid={0}',
          'fields':  
             {
                'dataAreaId': 'Value=mahy',
                'SalesQuotationNumber': 'mah_quotationnumber',
                'SalesPrice': 'ownerid',
                'RequestedSalesQuantity': 'Value=en-us',
                'ItemNumber': 'systemuser.personalemailaddress {systemuser.systemuserid = quote.owninguser}',
                'SalesProductCategoryName': 'opportunityid'               
             }
         }";

        public static readonly string _QuoteProjJsonModel =
        @"{
          'entity': 'quote',
          'filter': 'quoteid={0}',
          'fields':  
             {
                'dataAreaId': 'Value=mahy',
                'SalesQuotationNumber': 'mah_quotationnumber',
                'QuotationTakerPersonnelNumber': 'ownerid',
                'LanguageId': 'Value=en-us',
                'Email': 'systemuser.personalemailaddress {systemuser.systemuserid = quote.owninguser}',
                'OpportunityId': 'opportunityid',
                'RequestingCustomerAccountNumber': 'customerid',
                'CurrencyCode': 'transactioncurrency.isocurrencycode {transactioncurrency.transactioncurrencyid = quote.transactioncurrencyid}',  
                'PaymentTermsName': 'mah_paymentterms',
                'TotalDiscountPercentage': 'discountpercentage',
                'PWC_LPOAmount': 'Value={1}',
                'PWC_LPODate': 'Value=124',
                'DeliveryAddressName': 'account.name {account.accountid = quote.accountid}',
                'DeliveryAddressStreet': 'account.address1_line1 {account.accountid = quote.accountid}',
                'DeliveryAddressCity': 'account.mah_city {account.accountid = quote.accountid}',  
                'DeliveryAddressStateId': 'account.mah_state {account.accountid = quote.accountid}',
                'DeliveryAddressZipCode': 'account.mah_pincode {account.accountid = quote.accountid}',
                'DeliveryAddressCountryRegionId': 'account.mah_country {account.accountid = quote.accountid}',
                'DeliveryAddressDescription': 'account.name {account.accountid = quote.accountid}'
             }
         }";

        public static readonly string _QuoteProductProjJsonModel =
        @"{
          'entity': 'quote',
          'filter': 'quoteid={0}',
          'fields':  
             {
                'dataAreaId': 'Value=mahy',
                'ProjQuotationNumber': 'mah_quotationnumber',
                'SalesPrice': 'ownerid',
                'RequestedSalesQuantity': 'Value=en-us',
                'ProjCategoryId': 'systemuser.personalemailaddress {systemuser.systemuserid = quote.owninguser}',
                'ProjTransType' : 'mah_transactiontype',
                'SalesProductCategoryName': 'opportunityid'               
             }
         }";
        public static readonly string _ContactJsonModel =
        @"{
          'entity': 'account',
          'filter': 'accountid={0}',
          'filter1': 'emailaddress1={1}',
          'fields':  
             {
                'CustomerAccount': 'name',
                'CustomerID': 'mah_customerid',
                'Currency': 'transactioncurrencyid',
                'StreetAddress': 'address1_composite',
                'CityID': 'mah_city.mah_cityid {mah_city.mah_cityid = account.mah_city}',
                'CityName': 'mah_city.mah_name {mah_city.mah_cityid = account.mah_city}',
                'CityOwner': 'mah_city.ownerid(ID) {mah_city.mah_cityid = account.mah_city}',
                'StateID': 'mah_state.mah_stateid {mah_state.mah_stateid = account.mah_state}',
                'StateName': 'mah_state.mah_name {mah_state.mah_stateid = account.mah_state}',
                'Pincode': 'mah_pincode.mah_name {mah_pincode.mah_pincodeid = account.mah_pincode}',
                'CountryID': 'mah_country.mah_countryid {mah_country.mah_countryid = account.mah_country}',
                'CountryName': 'mah_country.mah_name {mah_country.mah_countryid = account.mah_country}',
             }
         }";



    }


    public class ApiConfigSettings
    {
        [JsonProperty("mah_name")]
        public string ApiName { get; set; }
        [JsonProperty("mah_clientid")]
        public string ClientId { get; set; }
        [JsonProperty("mah_clientsecret")]
        public string ClientSecret { get; set; }
        [JsonProperty("mah_orgresourceurl")]
        public string OrgResourceUrl { get; set; }
        [JsonProperty("mah_tokenurl")]
        public string TokenUrl { get; set; }
        [JsonProperty("mah_postgetapiurl")]
        public string PostGetApiUrl { get; set; }
    }

    public class Account
    {
        [JsonProperty("name")]
        public string CustomerAccount { get; set; }
        [JsonProperty("mah_customerid")]
        public string CustomerID { get; set; }
        //[JsonProperty("")]
        //public string CustomerGroup { get; set; }
        [JsonProperty("transactioncurrencyid")]
        public string Currency { get; set; }
        [JsonProperty("name")]
        public string Name { get; set; }
        [JsonProperty("address1_composite")]
        public string StreetAddress { get; set; }
        [JsonProperty("mah_city")]
        public string City { get; set; }
        [JsonProperty("mah_state")]
        public string State { get; set; }
        [JsonProperty("mah_pincode")]
        public string Pincode { get; set; }
        [JsonProperty("mah_country")]
        public string Country { get; set; }
        //[JsonProperty("")]
        //public string Address Description { get; set; }
        //[JsonProperty("")]
        //public string Descreption { get; set; }
        [JsonProperty("emailaddress1")]
        public string Email { get; set; }
        [JsonProperty("telephone1")]
        public string Phone { get; set; }
        [JsonProperty("paymenttermscode")]
        public string TermsofPayment { get; set; }
        //[JsonProperty("")]
        //public string Customer Hold Flag { get; set; }
        [JsonProperty("customertypecode")]
        public string RelationshipType { get; set; }

        //Refernce 
        [JsonProperty("accountid")]
        public string AccountGUID { get; set; }
        [JsonProperty("parentaccountid")]
        public string ParentAccountID { get; set; }
        [JsonProperty("primarycontactid")]
        public string PrimaryContactId { get; set; }
        [JsonProperty("msdyn_billingaccount")]
        public string BillingAccount { get; set; }
        [JsonProperty("masterid")]
        public string MasterID { get; set; }
    }

    public class Quote
    {
        [JsonProperty("quoteid")]
        public string QuoteID { get; set; }
        [JsonProperty("mah_quotationnumber")]
        public string QuotationNumber { get; set; }
        [JsonProperty("revisionnumber")]
        public string RevisionID { get; set; }
        [JsonProperty("bu.mk_legalentity")]
        public string LegalEntity { get; set; }      //=>  MAP BU Entity (Owner ID pass to BU), atrribute => mk_legalentity
        //[JsonProperty("")]
        //public string Quotation Type { get; set; }
        [JsonProperty("ownerid")]
        public string Owner { get; set; }
        [JsonProperty("effectivefrom")]
        public string EffectiveFrom { get; set; }
        [JsonProperty("effectiveto")]
        public string EffectiveTo { get; set; }
        [JsonProperty("pwc_projectname")]
        public string ProjectName { get; set; }
        [JsonProperty("opportunityid")]
        public string Opportunity { get; set; }
        [JsonProperty("customerid")]
        public string PotentialCustomer { get; set; }   // Accounnt ID
        [JsonProperty("mah_contractor")]
        public string Contractor { get; set; }
        [JsonProperty("transactioncurrencyid")]
        public string Currency { get; set; }
        [JsonProperty("mah_quoteremarks")]
        public string QuoteRemarks { get; set; }
        [JsonProperty("mah_paymentterms")]
        public string PaymentTermsPercentage { get; set; }
        [JsonProperty("mah_warranty")]
        public string Warranty { get; set; }
        [JsonProperty("mah_cancellationcharge")]
        public string CancellationChargePercentage { get; set; }
        [JsonProperty("mah_scopeofwork")]
        public string Scopeofwork { get; set; }
        [JsonProperty("totallineitemamount")]
        public string SubTotal { get; set; }
        [JsonProperty("discountpercentage")]
        public string DiscountPercentage { get; set; }
        [JsonProperty("discountamount")]
        public string Discount { get; set; }
        [JsonProperty("totalamountlessfreight")]
        public string PreFreightAmount { get; set; }
        [JsonProperty("freightamount")]
        public string FreightAmount { get; set; }
        [JsonProperty("mah_vattrn")]
        public string VAT { get; set; }
        [JsonProperty("totalamount")]
        public string Total { get; set; }
        [JsonProperty("mah_lpo")]
        public string LPONumber { get; set; }
        //[JsonProperty("")]
        //public string LPO Amount { get; set; }
        //[JsonProperty("")]
        //public string LPO Date { get; set; }
        [JsonProperty("billto_line1")]
        public string BillToStreet1 { get; set; }
        [JsonProperty("billto_line2")]
        public string BillToStreet2 { get; set; }
        [JsonProperty("billto_line3")]
        public string BillToStreet3 { get; set; }
        [JsonProperty("billto_city")]
        public string BillToCity { get; set; }
        [JsonProperty("billto_stateorprovince")]
        public string BillToStateProvince { get; set; }
        [JsonProperty("billto_stateorprovince")]
        public string BillToZIPPostalCode { get; set; }
        [JsonProperty("billto_country")]
        public string BillToCountryRegion { get; set; }
        [JsonProperty("billto_name")]
        string BillToName { get; set; }
        [JsonProperty("billto_telephone")]
        public string BillToPhone { get; set; }
        [JsonProperty("emailaddress")]
        public string BillToEmailAddress { get; set; }
        [JsonProperty("willcall")]
        public string ShipTo { get; set; }
        [JsonProperty("shipto_line1")]
        public string ShipToStreet1 { get; set; }
        [JsonProperty("shipto_line2")]
        public string ShipToStreet2 { get; set; }
        [JsonProperty("shipto_line3")]
        public string ShipToStreet3 { get; set; }
        [JsonProperty("shipto_city")]
        public string ShipToCity { get; set; }
        [JsonProperty("shipto_stateorprovince")]
        public string ShipToStateProvince { get; set; }
        [JsonProperty("shipto_postalcode")]
        public string ShipToZIPPostalCode { get; set; }
        [JsonProperty("shipto_country")]
        public string ShipToCountryRegion { get; set; }
        [JsonProperty("mah_quotationtype")]
        public string QuotationType { get; set; }


        //Reference 
        //[JsonProperty("contactid")]
        //public string ContactID { get; set; }
        //[JsonProperty("msdyn_account")]
        //public string MsDynAccount { get; set; }
        //[JsonProperty("accountid")]
        //public string AccountID { get; set; }
        //[JsonProperty("mah_contractor")]
        //public string MahContractor { get; set; }
        //[JsonProperty("pwc_contractor")]
        //public string PwcContractor { get; set; }
    }

    public class QuoteDetail
    {
        [JsonProperty("productdescription")]
        public string ProductWriteInProduct { get; set; }
        [JsonProperty("isproductoverridden")]
        public string WriteIn { get; set; }
        [JsonProperty("ispriceoverridden")]
        public string Pricing { get; set; }
        [JsonProperty("priceperunit")]
        public string PricePerUnit { get; set; }
        [JsonProperty("quantity")]
        public string Quantity { get; set; }
        [JsonProperty("baseamount")]
        public string Amount { get; set; }
        [JsonProperty("manualdiscountamount")]
        public string ManualDiscount { get; set; }
        [JsonProperty("tax")]
        public string Tax { get; set; }
        [JsonProperty("extendedamount")]
        public string ExtendedAmount { get; set; }
        //Reference 
        [JsonProperty("quotedetailid")]
        public string QuoteDetailId { get; set; }
        [JsonProperty("parentbundleidref")]
        public string ParentBundleIdRef { get; set; }
        [JsonProperty("quoteid")]
        public string QuoteID { get; set; }
        [JsonProperty("msdyn_serviceaccount")]
        public string MsDynServiceAccount { get; set; }
        [JsonProperty("mah_projectcategory")]
        public string ProjectCategory { get; set; }
        [JsonProperty("mah_transactiontype")]
        public string TransactionType { get; set; }



    }

    public class Contact
    {
        [JsonProperty("address1_primarycontactname")]
        public string ContactName { get; set; }
        [JsonProperty("parentcustomerid")]
        public string Accountid { get; set; }  // Related Account 
        [JsonProperty("telephone1")]
        public string BusinessPhone { get; set; }
        [JsonProperty("address1_composite")]
        public string Address { get; set; }
        [JsonProperty("ownerid")]
        public string Owner { get; set; }
        [JsonProperty("mobilephone")]
        public string MobileNo { get; set; }
        [JsonProperty("emailaddress1")]
        public string Emailid { get; set; }

        //Reference
        //[JsonProperty("contactid")]
        //public string ContactID { get; set; }
        //[JsonProperty("parentcontactid")]
        //public string ParentContactID { get; set; }
        ////[JsonProperty("pwcmanager")]
        ////public string PwcManager { get; set; }
        //[JsonProperty("masterid")]
        //public string MasterID { get; set; }
        //[JsonProperty("accountid")]
        //public string AccountID { get; set; }
    }

}
