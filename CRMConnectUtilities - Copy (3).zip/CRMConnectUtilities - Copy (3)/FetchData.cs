﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRMConnectUtilities
{
    class FetchData
    {



        public static EntityCollection EntityDataColl(IOrganizationService service, string _QueryFor, string Param)
        {
            string fetchquery = string.Empty;
            var fetchData = new
            {
                ParamData = Param
            };

            if (_QueryFor == "_ConfigSetting")
            {

                 fetchquery = $@"<fetch distinct='true'>
                            <entity name='mah_crmfoapiintegrationsetting'>
                            <attribute name='mah_name' />
                            <attribute name='mah_clientid' />
                            <attribute name='mah_clientsecret' />
                            <attribute name='mah_orgresourceurl' />
                            <attribute name='mah_tokenurl' />
                            <attribute name='mah_postgetapiurl' />
                            <attribute name='mah_executionsequence' />
                            <filter>
                              <condition attribute='mah_name' operator='eq' value='{fetchData.ParamData}' />
                            </filter>
                          </entity>
                        </fetch>";
            }
            if (_QueryFor == "_legalEntity")
            {
                fetchquery = $@"<fetch distinct='true'>
                                      <entity name='quote'>
                                        <attribute name='customerid' />
                                        <link-entity name='systemuser' to='createdby' from='systemuserid' alias='usr' link-type='outer'>
                                          <link-entity name='businessunit' to='businessunitid' from='businessunitid' alias='bu' link-type='outer'>
                                            <link-entity name='mah_legalentity' to='mk_legalentity' from='mah_legalentityid' alias='le' link-type='outer'>
                                              <attribute name='mah_name' />
                                              <order attribute='mah_name' />
                                            </link-entity>
                                          </link-entity>
                                        </link-entity>
                                        <filter>
                                          <condition attribute='quoteid' operator='eq' value='{fetchData.ParamData}' />
                                        </filter>
                                        <order attribute='customerid' />
                                      </entity>
                                    </fetch>";
            }

            EntityCollection _Entitys = service.RetrieveMultiple(new FetchExpression(fetchquery));
            return _Entitys;
        }
        

    }
}
