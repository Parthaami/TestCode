﻿using Microsoft.Xrm.Sdk.PluginTelemetry;
using Simple.OData.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace CRMConnectUtilities
{
    class ODataHttpClient
    {
        private ODataClient GetODataClient()
        {
            try
            {
                string url = _config.GetSection("APIDetails:URL").Value;
                String username = _config.GetSection("APIDetails:UserName").Value;
                String password = _config.GetSection("APIDetails:Password").Value;

                String accessToken = System.Convert.ToBase64String(System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(username + ":" + password));

                var oDataClientSettings = new ODataClientSettings(new Uri(url));
                oDataClientSettings.BeforeRequest += delegate (HttpRequestMessage message)
                {
                    message.Headers.Add("Authorization", "Basic " + accessToken);
                };

                var client = new ODataClient(oDataClientSettings);

                Simple.OData.Client.V4Adapter.Reference();

                return client;
            }
            catch (Exception ex)
            {
                LogError("", $"Failed to connect API Services : {ex.Message}");
            }

            return null;
        }
    }
}
