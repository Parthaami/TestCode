﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using Newtonsoft.Json.Linq;
using System;
using System.Configuration;
using System.Dynamic;
using System.Linq;

namespace CRMConnectUtilities
{
    class Program
    {
        static void Main(string[] args)
        {

            string connectionString = ConfigurationManager.ConnectionStrings["MyCRMServer"].ToString();
            using (var service = new CrmServiceClient(connectionString))
            {
                if (service != null)
                {

                    Guid QuoteID = Guid.Parse("{73029632-b6ae-ec11-9840-000d3ab85977}");
                    //string StatusCode_Won = "4";
                    //EntityCollection ecQuote = RetrivedAllQuote.RetrieveAllWonQuote(service, StatusCode_Won);

                    //if (ecQuote.Entities.Count > 0)
                    //{
                    //    foreach (Entity _QuoteVal in ecQuote.Entities)
                    //    {
                    //        QuoteID = (Guid)_QuoteVal["quoteid"];



                    EntityCollection legalEntitys = FetchData.EntityDataColl(service, "_legalEntity", "73029632-b6ae-ec11-9840-000d3ab85977");//service.RetrieveMultiple(new FetchExpression(fetchquery));
                    var _legalEntity = (AliasedValue)legalEntitys[0]["le.mah_name"];
                    var _accounGuid = ((EntityReference)legalEntitys[0]["customerid"]).Id;
                    
                    Quote _ModelQuote = new Quote();
                    Account _ModelAccount = new Account();

                    #region CUSTOMER/ACCOUNT

                    //New Customer => 42a0b9ac-8cef-eb11-bacb-000d3ab31ca0
                    //Guid _accountid = Guid.Parse("" + _ModelQuote.PotentialCustomer);
                    Guid _accountid = _accounGuid; //Guid.Parse("42a0b9ac-8cef-eb11-bacb-000d3ab31ca0");
                    string _AccountProperties = DynamicJsonModel._AccountCustomersJsonModel;
                    _AccountProperties = _AccountProperties.Replace("{0}", "" + _accountid);
                    _AccountProperties = _AccountProperties.Replace("{1}", ""+ _legalEntity.Value);
                    JToken JsonAccount = Data.GetCrmEntityValueFromAnyJsonModel(service, _AccountProperties);
                    string CustomerAccount = JsonAccount["CustomerAccount"].ToString();
                    string AccountGUID = JsonAccount["CustomerAccount"].ToString();
                    //JsonAccount.RemoveFields(new string[] { "AccountGUID", "CityID", "CountryID", "CountryName" });

                    //Retrive PartyNumber
                    //string _getURL = "https://mkdeveloper2d8ea4770c25ecc53devaos.cloudax.dynamics.com/data/CustomersV2?$select=PartyNumber&$filter=CustomerAccount eq '"+ CustomerAccount + "'";

                    Guid _parentAccountid = _accounGuid;
                    string JsonContact = Data.JsonGetContact(service, _parentAccountid);

                    #endregion


                    string _QuoteSalesProperties = DynamicJsonModel._QuoteSalesJsonModel;
                    _QuoteSalesProperties = _QuoteSalesProperties.Replace("{0}", "" + QuoteID);
                    _QuoteSalesProperties = _QuoteSalesProperties.Replace("{1}", ""+ _legalEntity.Value);
                    JToken JsonQuote1 = Data.GetCrmEntityValueFromAnyJsonModel(service, _QuoteSalesProperties);

                    string JsonQuote = Data.JsonGetQuote(service, QuoteID, ref _ModelQuote);
                    string JsonQuoteDeatil = Data.JsonGetQuoteDetail(service, QuoteID);



                    ApiConfigSettings _apiConfig = new ApiConfigSettings();

                    EntityCollection listApiConfigs = Data.GetApiConfigurations(service, _apiConfig);

                   // var q = listApiConfigs.Entities.AsEnumerable().Where(x => x.Attributes["mah_name"].Equals("ErpCustomersApi") && x.Attributes["mk_executionsequence"].Equals("1")).Select(x => x.Attributes.Values);



                        //string ExecutionSequence = listApiConfigs[0].GetAttributeValue<string>("mah_executionsequence"); 
                        //string AuthenticationType = "OAUTH2.0";//_ApiConfig.AuthenticationType;

                        string Apiname = "";
                    //ApiURL = "https://mkdeveloper304448fae11374188devaos.axcloud.dynamics.com/api/services/PWC_CEAPI/PWC_WarrantyService/Invoicedata";
                    //ApiKey = "";
                    //AuthenticationType = "OAUTH2.0";//_ApiConfig.AuthenticationType;

                    string ApiExecutionResult = "";
                    //string _ConfigSetting = string.Empty;
                    string ClientId = string.Empty;
                    string ClientSecret = string.Empty;
                    string OrgResourceUrl = string.Empty;
                    string TokenUrl = string.Empty;
                    string PostGetApiUrl = string.Empty;

                    EntityCollection ConfigSetting = FetchData.EntityDataColl(service, "_ConfigSetting", "ErpCustomersApi");
                    string _ConfigSettingErpCustomersApi = ConfigSetting[0]["mah_name"].ToString();
                    ClientId = ConfigSetting[0]["mah_clientid"].ToString();
                    ClientSecret = ConfigSetting[0]["mah_clientsecret"].ToString();
                    OrgResourceUrl = ConfigSetting[0]["mah_orgresourceurl"].ToString();
                    TokenUrl = ConfigSetting[0]["mah_tokenurl"].ToString();
                    PostGetApiUrl = ConfigSetting[0]["mah_postgetapiurl"].ToString();

                    if (_ConfigSettingErpCustomersApi == "ErpCustomersApi")
                    {
                        ApiExecutionResult = Utilities.callAPI(ClientId, ClientSecret, OrgResourceUrl, TokenUrl, PostGetApiUrl, JsonAccount.ToString(),"Y");
                        //Yes => 809880000   , No => 809880001
                        Utilities.CreateLog("CustomersApi",JsonAccount.ToString(), PostGetApiUrl, ApiExecutionResult, 809880000, "", service);
                    }
                    if(ApiExecutionResult.Contains("Infolog:"))
                    {
                        return;
                    }                    

                    EntityCollection ConfigSetting1 = FetchData.EntityDataColl(service, "_ConfigSetting", "ErpContactPersonsApi");
                    string _ConfigSettingErpContactPersonsApi = ConfigSetting1[0]["mah_name"].ToString();
                    PostGetApiUrl = ConfigSetting1[0]["mah_postgetapiurl"].ToString();

                    string _ContactPesronJsonModel = DynamicJsonModel._ContactPesronJsonModel;
                    _ContactPesronJsonModel = _ContactPesronJsonModel.Replace("{0}", "" + _accountid);
                    _ContactPesronJsonModel = _ContactPesronJsonModel.Replace("{1}", "" + _legalEntity.Value);
                    _ContactPesronJsonModel = _ContactPesronJsonModel.Replace("{2}", "" + ApiExecutionResult);
                    JToken JsonContactPerson = Data.GetCrmEntityValueFromAnyJsonModel(service, _ContactPesronJsonModel);


                    if (_ConfigSettingErpContactPersonsApi == "ErpContactPersonsApi")
                    {

                        ApiExecutionResult = Utilities.callAPI(ClientId, ClientSecret, OrgResourceUrl, TokenUrl, PostGetApiUrl, JsonContactPerson.ToString());
                        //Yes => 809880000   , No => 809880001
                        Utilities.CreateLog("ContactPersonsApi",JsonQuoteDeatil, PostGetApiUrl, ApiExecutionResult, 809880000, "", service);
                    }

                    EntityCollection ConfigSetting2 = FetchData.EntityDataColl(service, "_ConfigSetting", "ErpContactPersonsApi");
                    string _ConfigSettingErpSalesQuotationHeadersApi = ConfigSetting1[0]["mah_name"].ToString();
                    PostGetApiUrl = ConfigSetting2[0]["mah_postgetapiurl"].ToString();





                    if (_ConfigSettingErpSalesQuotationHeadersApi == "ErpSalesQuotationHeadersApi")
                    {
                        //ApiExecutionResult = Utilities.GetAPIResult(ApiURL, AuthenticationType, ApiKey, JsonAccount);
                        ApiExecutionResult = Utilities.callAPI(ClientId, ClientSecret, OrgResourceUrl, TokenUrl, PostGetApiUrl, JsonContactPerson.ToString());
                        //Yes => 809880000   , No => 809880001
                        Utilities.CreateLog("SalesQuotationHeadersApi", JsonQuoteDeatil, PostGetApiUrl, ApiExecutionResult, 809880000, "", service);
                    }

                    //EntityCollection ConfigSetting2 = FetchData.EntityDataColl(service, "_ConfigSetting", "ErpContactPersonsApi");
                    //string _ConfigSettingErpSalesQuotationHeadersApi = ConfigSetting1[0]["mah_name"].ToString();
                    //PostGetApiUrl = ConfigSetting2[0]["mah_postgetapiurl"].ToString();


                    //EntityCollection ConfigSetting = FetchData.EntityDataColl(service, "_ConfigSetting", "ErpContactPersonsApi");//service.RetrieveMultiple(new FetchExpression(fetchquery));
                    //var _ConfigSetting = ConfigSetting[0]["mah_name"];
                    //EntityCollection ConfigSetting = FetchData.EntityDataColl(service, "_ConfigSetting", "ErpSalesQuotationHeadersApi");//service.RetrieveMultiple(new FetchExpression(fetchquery));
                    //var _ConfigSetting = ConfigSetting[0]["mah_name"];
                    //EntityCollection ConfigSetting = FetchData.EntityDataColl(service, "_ConfigSetting", "ErpSalesQuotationLinesApi");//service.RetrieveMultiple(new FetchExpression(fetchquery));
                    //var _ConfigSetting = ConfigSetting[0]["mah_name"];
                    //EntityCollection ConfigSetting = FetchData.EntityDataColl(service, "_ConfigSetting", "ErpCustomersApi");//service.RetrieveMultiple(new FetchExpression(fetchquery));
                    //var _ConfigSetting = ConfigSetting[0]["mah_name"];



                    //string _PartyNumber = "";


                    /*
                    if (Apiname == "ErpCustomersApi"  )
                        {
                            ApiExecutionResult = Utilities.callAPI(ClientId, ClientSecret, OrgResourceUrl, TokenUrl, PostGetApiUrl, JsonAccount.ToString());
                            //Yes => 809880000   , No => 809880001
                            Utilities.CreateLog(JsonQuoteDeatil, PostGetApiUrl, ApiExecutionResult, 809880000, "", service);
                        }
                        if (Apiname == "ErpContactPersonsApi")
                        {

                            ApiExecutionResult = Utilities.callAPI(ClientId, ClientSecret, OrgResourceUrl, TokenUrl, PostGetApiUrl, JsonQuote);
                            //Yes => 809880000   , No => 809880001
                            Utilities.CreateLog(JsonQuoteDeatil, PostGetApiUrl, ApiExecutionResult, 809880000, "", service);
                        }
                        if (Apiname == "ErpSalesQuotationHeadersApi")
                        {
                            //ApiExecutionResult = Utilities.GetAPIResult(ApiURL, AuthenticationType, ApiKey, JsonAccount);
                            ApiExecutionResult = Utilities.callAPI(ClientId, ClientSecret, OrgResourceUrl, TokenUrl, PostGetApiUrl, JsonQuote);
                            //Yes => 809880000   , No => 809880001
                            Utilities.CreateLog(JsonQuoteDeatil, PostGetApiUrl, ApiExecutionResult, 809880000, "", service);
                        }
                        if (Apiname == "ErpSalesQuotationLinesApi")
                        {
                            ApiExecutionResult = Utilities.callAPI(ClientId, ClientSecret, OrgResourceUrl, TokenUrl, PostGetApiUrl, JsonQuote);
                            //Yes => 809880000   , No => 809880001
                            Utilities.CreateLog(JsonQuoteDeatil, PostGetApiUrl, ApiExecutionResult, 809880000, "", service);
                        }
                        if (Apiname == "ErpProjQuotationHeadersApi")
                        {
                            //ApiExecutionResult = Utilities.GetAPIResult(ApiURL, AuthenticationType, ApiKey, JsonAccount);
                            ApiExecutionResult = Utilities.callAPI(ClientId, ClientSecret, OrgResourceUrl, TokenUrl, PostGetApiUrl, JsonQuote);
                            //Yes => 809880000   , No => 809880001
                            Utilities.CreateLog(JsonQuoteDeatil, PostGetApiUrl, ApiExecutionResult, 809880000, "", service);
                        }
                        if (Apiname == "ProjQuotationLines")
                        {
                            ApiExecutionResult = Utilities.callAPI(ClientId, ClientSecret, OrgResourceUrl, TokenUrl, PostGetApiUrl, JsonQuote);
                            //Yes => 809880000   , No => 809880001
                            Utilities.CreateLog(JsonQuoteDeatil, PostGetApiUrl, ApiExecutionResult, 809880000, "", service);
                        }
                    */
                    //}

                    Console.ReadLine();
                }
            }
        }
    }
}
                  


                    
               

       
        
    

