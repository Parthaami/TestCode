﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace CRMConnectUtilities
{
    public static class Utilities
    {


        /// <summary>
        /// ConvertToSecureString
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        private static System.Security.SecureString ConvertToSecureString(string password)
        {
            if (password == null)
                throw new ArgumentException("missing pwd");

            var securePassword = new System.Security.SecureString();
            foreach (char c in password)
                securePassword.AppendChar(c);

            securePassword.MakeReadOnly();
            return securePassword;

        }

        /*
         * 
        //S2S Authentication
        internal static OrganizationWebProxyClient GetS2SService(string hostName, string clientid, string clientsecret)
        {
            //hostName = CrmInstance;
            ClientCredential clientcred = new ClientCredential(clientid, clientsecret);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            //AuthenticationContext authenticationContext =
            // new AuthenticationContext("https://login.microsoftonline.com/{clientId}");

            AuthenticationContext authenticationContext =
    new AuthenticationContext("https://login.windows.net/common", false);

            authenticationContext.TokenCache.Clear();

            AuthenticationResult authenticationResult =
             authenticationContext.AcquireTokenAsync(hostName, clientcred).Result;
            var _service = new OrganizationWebProxyClient(new Uri($"{hostName}/xrmservices/2011/organization.svc/web?SdkClientVersion=9.0"), TimeSpan.MaxValue, false);
            _service.HeaderToken = authenticationResult.AccessToken;
            return _service;
        }

        public static string GetAccessTokenSrc(string hostName, string clientid, string clientsecret)
        {
            ClientCredential clientcred = new ClientCredential(clientid, clientsecret);
            AuthenticationContext authenticationContext =
             new AuthenticationContext("https://login.microsoftonline.com/{clientID}");

            authenticationContext.TokenCache.Clear();

            AuthenticationResult authenticationResult =
             authenticationContext.AcquireTokenAsync(hostName, clientcred).Result;

            return authenticationResult.AccessToken;
        }
     */

        /// <summary>
        /// RemoveFields
        /// </summary>
        /// <param name="token"></param>
        /// <param name="fields"></param>
        /// <returns></returns>
        public static JToken RemoveFields(this JToken token, string[] fields)
        {
            JContainer container = token as JContainer;
            if (container == null) return token;

            List<JToken> removeList = new List<JToken>();
            foreach (JToken el in container.Children())
            {
                JProperty p = el as JProperty;
                if (p != null && fields.Contains(p.Name))
                {
                    removeList.Add(el);
                }
                el.RemoveFields(fields);
            }

            foreach (JToken el in removeList)
            {
                el.Remove();
            }

            return token;
        }


        /// <summary>
        /// GetAttributeValues (Retrieve Any Type Of (Entity) Attribute Value)
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="FieldSchemaName"></param>
        /// <param name="FormattedValue"></param>
        /// <returns>Attribute Value</returns>
        private static string GetAttributeValues(Entity entity, string FieldSchemaName, bool FormattedValue = true)
        {
            if (!entity.Contains(FieldSchemaName))
            {
                return "";
            }
            var EntityAttribute = entity.Attributes[FieldSchemaName];
            string AttributeTypeName = EntityAttribute.GetType().Name;

            if (AttributeTypeName.Equals("AliasedValue"))
            {
                EntityAttribute = ((AliasedValue)entity.Attributes[FieldSchemaName]).Value;
                AttributeTypeName = EntityAttribute.GetType().Name;
            }
            string AttributeValueGUID = "";
            string AttributeValueName = "";
            switch (AttributeTypeName)
            {
                case "OptionSetValue":
                    OptionSetValue AttributeOptionSetValue = (OptionSetValue)EntityAttribute;
                    AttributeValueGUID = "" + AttributeOptionSetValue.Value;
                    break;
                case "EntityReference":
                    EntityReference AttributeReference = (EntityReference)EntityAttribute;
                    AttributeValueGUID = "" + AttributeReference.Id;
                    AttributeValueName = AttributeReference.Name;
                    break;
                case "Guid":
                    AttributeValueGUID = "" + EntityAttribute;
                    break;
                case "Money":
                    AttributeValueName = "" + Convert.ToString(((Money)EntityAttribute).Value);
                    break;
                case "DateTime":
                    AttributeValueName = "" + Convert.ToString(((DateTime)EntityAttribute));
                    break;
                case "Int32":
                    AttributeValueName = "" + Convert.ToString(((Int32)EntityAttribute));
                    break;
                case "String":
                    AttributeValueName = "" + Convert.ToString(((String)EntityAttribute));
                    break;
                case "bool":
                    AttributeValueName = "" + Convert.ToString(((bool)EntityAttribute));
                    break;
            }

            if (FormattedValue)
            {
                if (AttributeValueName.Trim() == "")
                    return AttributeValueGUID;
                else
                    return AttributeValueName;
            }
            else
            {
                return AttributeValueGUID;
            }

        }


        /// <summary>
        /// GetDynamicJsonArrayFromFetchXML
        /// </summary>
        /// <param name="FetchedRecordsCollection"></param>
        /// <param name="EntityAttributeList"></param>
        /// <returns>JSON Array</returns>
        public static JToken GetDynamicJsonArrayFromFetchXML(
              EntityCollection FetchedRecordsCollection
            , List<DynamicJsonClass> EntityAttributeList
            )
        {
            JObject ObjJSON = new JObject();
            try
            {
                if (FetchedRecordsCollection == null)
                {
                    ObjJSON.Add("message", "No Data Found!");
                    return ObjJSON;
                }
                if (FetchedRecordsCollection.Entities.Count < 1)
                {
                    ObjJSON.Add("message", "No Data Found!");
                    return ObjJSON;
                }

                List<dynamic> ObjList = new List<dynamic>();

                foreach(Entity EntityResult in FetchedRecordsCollection.Entities)
                {
                    ObjJSON = new JObject();
                    foreach (DynamicJsonClass Model in EntityAttributeList)
                    {
                        string UserAttributeName = Model.FieldUserName;
                        string EntityAlias = ("" + Model.LinkedEntityName).Trim();
                        string EntityAttributeName = Model.EntityAttributeName;
                        bool isFormattedValue = !Model.IdValueOnly;
                        string EntityAttributeValue = GetAttributeValues(EntityResult, EntityAttributeName, isFormattedValue);
                        ObjJSON.Add(UserAttributeName, EntityAttributeValue);
                    }
                    ObjList.Add(JsonConvert.DeserializeObject<dynamic>(ObjJSON.ToString()));
                }

                string JsonString = JsonConvert.SerializeObject(ObjList, Formatting.Indented);
                JsonString = JsonString.Substring(5, JsonString.Length - 8); ;
                return JToken.Parse(JsonString);
            }
            catch (Exception ex)
            {
                ObjJSON.Add("Error", ex.Message);
                return ObjJSON;
            }

       }


        /// <summary>
        /// GetJsonArrayFromFetchXML
        /// </summary>
        /// <param name="FetchedRecordsCollection"></param>
        /// <param name="objSchemaMappingClass"></param>
        /// <returnsJSON Array As String & Populate All Field Values Of objSchemaMappingClass></returns>
        public static string GetJsonArrayFromFetchXML(
              EntityCollection FetchedRecordsCollection
            , object objSchemaMappingClass
            )
        {
            JObject ObjJSON = new JObject();
            try
            {
                if (FetchedRecordsCollection == null)
                {
                    ObjJSON.Add("message", "No Data Found!");
                    return ObjJSON.ToString();
                }
                if (FetchedRecordsCollection.Entities.Count < 1)
                {
                    ObjJSON.Add("message", "No Data Found!");
                    return ObjJSON.ToString();
                }
                else
                {
                    List<dynamic> ObjList = new List<dynamic>();
                    PropertyInfo[] ClasProperties = objSchemaMappingClass.GetType()
                                                    .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                    foreach (Entity objEntity in FetchedRecordsCollection.Entities)
                    {
                        ObjJSON = new JObject();
                        foreach (PropertyInfo Attribute in ClasProperties)
                        {
                            string AttributeName = Attribute.Name;
                            string EntityAttributeName = Attribute.Name;
                            if (Attribute.GetCustomAttributesData().Count > 0)
                            {
                                var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                                if (EntityAttributeCollection.Count > 0)
                                {
                                    EntityAttributeName = "" + EntityAttributeCollection[0].Value;
                                }
                            }
                            bool isFormattedValue = EntityAttributeName == "customerid" ? false : true;
                            string EntityAttributeValue = "" + GetAttributeValues(objEntity, EntityAttributeName, isFormattedValue);
                            Attribute.SetMethod.Invoke(objSchemaMappingClass, new object[] { EntityAttributeValue });
                            //Attribute.GetValue(objSchemaMappingClass, null);
                            ObjJSON.Add(AttributeName, EntityAttributeValue);
                        }

                        ObjList.Add(JsonConvert.DeserializeObject<dynamic>(ObjJSON.ToString()));
                    }

                    return JsonConvert.SerializeObject(ObjList, Formatting.Indented);
                }
            }
            catch (Exception ex)
            {
                ObjJSON.Add("Error", ex.Message);
                return ObjJSON.ToString();
            }

        }


        /// <summary>
        /// GetAPIResult
        /// </summary>
        /// <param name="strBaseAddress"></param>
        /// <param name="AccessTypeHeader"></param>
        /// <param name="strAccessToken"></param>
        /// <param name="strMethodName"></param>
        /// <param name="strJsonInput"></param>
        /// <param name="responseObject"></param>
        /// <param name="strResult"></param>
        /// <param name="TotalRecords"></param>
        /// <param name="Exception"></param>
        /// <returns></returns>
        public static string GetAPIResult(string strBaseAddress,
                                     string AccessTypeHeader,
                                     string strAccessToken,
                                     string strJsonInput
                                     )
        {
            MemoryStream ResponseStream = new MemoryStream();
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3
                | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                HttpWebRequest postRequest = (HttpWebRequest)WebRequest.Create(strBaseAddress);
                postRequest.ContentType = "application/json";
                postRequest.Method = "POST";
                postRequest.Timeout = 50000;
                postRequest.Headers.Add(AccessTypeHeader, strAccessToken);
                StreamWriter requeststream = new StreamWriter(postRequest.GetRequestStream());
                dynamic inputData = JsonConvert.DeserializeObject(strJsonInput);
                var json = JsonConvert.SerializeObject(inputData);
                requeststream.Write(json);
                requeststream.Close();
                try
                {
                    HttpWebResponse getResponse = (HttpWebResponse)postRequest.GetResponse();
                    return "" + getResponse;
                }
                catch (WebException ex)
                {
                    return "" + ex.Response + Environment.NewLine + ex.Message;
                }

            }
            catch (Exception ex)
            {
                return ex.Message;
            }

            //return string.Empty;
        }

       

        /// <summary>
        /// CreateLog
        /// </summary>
        /// <param name="requestObject"></param>
        /// <param name="ApiURL"></param>
        /// <param name="response"></param>
        /// <param name="Status"></param>
        /// <param name="errorMessage"></param>
        /// <param name="_service"></param>
        public static void CreateLog(string _Action,string requestObject, String ApiURL, String response, int Status, string errorMessage, IOrganizationService _service)
        {
            try
            {
                var entity = new Entity("mah_crmfoapiintegrationlog");
                entity.Attributes["mah_requestbody"] = requestObject;
                if (!String.IsNullOrEmpty(errorMessage))
                {
                    entity.Attributes["mah_errormessage"] = errorMessage;
                }
                entity.Attributes["mah_name"] = _Action;
                entity.Attributes["mah_issuccess"] = new OptionSetValue(Status);
                entity.Attributes["mah_apiurl"] = ApiURL;
                entity.Attributes["mah_response"] = response;
                _service.Create(entity);

            }
            catch (Exception ex)
            {
                //return Guid.Empty;
            }
        }


        #region Integration CRM to FO
        //public static string GetAccessToken(string ClientID, string ClientSecret, string Resource, string tokenURL)
        //{
        //    TokenDetails tokenObj = new TokenDetails();

        //    var dataToPost = "grant_type=client_credentials&client_id=" + ClientID + "&client_secret=" + ClientSecret + "&resource=" + Resource;

        //    var contentType = "application/x-www-form-urlencoded";
        //    var response = GetWebResponse(new Uri(tokenURL), "", contentType, "POST", dataToPost);
        //    using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(response)))
        //    {
        //        // Deserialization from JSON  
        //        DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(TokenDetails));
        //        tokenObj = (TokenDetails)deserializer.ReadObject(ms);
        //        return tokenObj.access_token;
        //    }
        //}

        public static string GetFnOToken(string clientId, string client_secret, string orgResourceUrl, string tokenURL)
        {
            try
            {
                //string organizationUrl = " https://mkdeveloper304448fae11374188devaos.axcloud.dynamics.com"; //resource
                //string clientId = "6b72230d-bea6-499c-a6e7-a3444d1c7fc6"; // Client Id
                //string appKey = "SdI7Q~2smLIZOLe-.EoS-G1Yg4M6oDv3QPEAT"; //Client Secret
                //string loginUrl = "https://login.microsoftonline.com/common/oauth2/token";

                using (var httpClient = new HttpClient())
                {
                    using (var request = new HttpRequestMessage(new HttpMethod("POST"), tokenURL))
                    {
                        var contentList = new List<string>
                        {
                            $"client_id={Uri.EscapeDataString(clientId)}",
                            $"resource={Uri.EscapeDataString(orgResourceUrl)}",
                            $"client_secret={Uri.EscapeDataString(client_secret)}",
                            $"grant_type={Uri.EscapeDataString("client_credentials")}"
                        };
                        request.Content = new StringContent(string.Join("&", contentList));
                        request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("application/x-www-form-urlencoded");

                        var response = httpClient.SendAsync(request).GetAwaiter().GetResult();
                        if (response.IsSuccessStatusCode)
                        {
                            var jsonConverter = JsonConvert.DeserializeObject<Dictionary<string, string>>(response.Content.ReadAsStringAsync().GetAwaiter().GetResult());
                            if (jsonConverter.ContainsKey("access_token"))
                            {
                                var token = jsonConverter["access_token"];
                                return token;
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error", e.Message);
                return null;
            }
        }

        public static string GetWebResponse(Uri url, string bearerToken, string contentType, string type, string data, byte[] bdata = null)
        {
            bearerToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6ImpTMVhvMU9XRGpfNTJ2YndHTmd2UU8yVnpNYyIsImtpZCI6ImpTMVhvMU9XRGpfNTJ2YndHTmd2UU8yVnpNYyJ9.eyJhdWQiOiJodHRwczovL21rZGV2ZWxvcGVyMmQ4ZWE0NzcwYzI1ZWNjNTNkZXZhb3MuY2xvdWRheC5keW5hbWljcy5jb20iLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mOGNkZWYzMS1hMzFlLTRiNGEtOTNlNC01ZjU3MWU5MTI1NWEvIiwiaWF0IjoxNjQ5NjY0NjkwLCJuYmYiOjE2NDk2NjQ2OTAsImV4cCI6MTY0OTc1MTM5MCwiYWlvIjoiRTJaZ1lEaG1QVVhCSk5pSHRlMjJ6SjJJcDJXbEFBPT0iLCJhcHBpZCI6IjZiNzIyMzBkLWJlYTYtNDk5Yy1hNmU3LWEzNDQ0ZDFjN2ZjNiIsImFwcGlkYWNyIjoiMSIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0L2Y4Y2RlZjMxLWEzMWUtNGI0YS05M2U0LTVmNTcxZTkxMjU1YS8iLCJyaCI6IjAuQVNZQU1lX04tQjZqU2t1VDVGOVhIcEVsV2hVQUFBQUFBQUFBd0FBQUFBQUFBQUFCQUFBLiIsInRpZCI6ImY4Y2RlZjMxLWEzMWUtNGI0YS05M2U0LTVmNTcxZTkxMjU1YSIsInV0aSI6IlExWXAyellOaTBXMzNOTUdwRnNrQVEiLCJ2ZXIiOiIxLjAifQ.ZjF-jhVSLbfiCt9C9NwnDFnDXsiNCxxqqNskv_IG3fv5pKwWaALxPsIEE-4wmEHBl6Ig24NUvrIyXnYUKbMSdgbEL1V6qKPZexCjkyMnf1x-kGIcyOOQZQ6gziWU12JJEP30xmMrGVEzrj3-CIt5Lvxi3gn-H0WVvxjWzYaEa68UH3NLo0t6xOgkFtb3-EKYT608i3AidWf70aBzBqqOgmRR7jSfXdnYXYTPiE8Wrg6nw73BkYTmFyJQZHVbj6OAjjlUdqsTo9Leo11nDljSIRATfPENG6QehDwkhhcbKnpKUbclTz_RvIFiCU8X16fZLorucyALdFo2B2cScsGNFA";
            System.Net.WebResponse resp;
            try
            {
                System.Net.WebRequest req = System.Net.WebRequest.Create(url);

                req.ContentType = contentType;// "application/json";
                req.Method = type;
                if (!string.IsNullOrEmpty(bearerToken))
                {
                    req.Headers.Add(HttpRequestHeader.Authorization, String.Format("Bearer {0}", bearerToken));
                }

                if (!string.IsNullOrEmpty(data) || (bdata != null))
                {
                    byte[] bytes = !string.IsNullOrEmpty(data) ? System.Text.Encoding.ASCII.GetBytes(data) : bdata ?? null;
                    req.ContentLength = bytes.Length;
                    System.IO.Stream os = req.GetRequestStream();
                    os.Write(bytes, 0, bytes.Length);
                    os.Close();
                }
                else
                {
                    req.ContentLength = 0;
                }
                resp = req.GetResponse();
            }
            catch (WebException e)
            {
                string _retError = string.Empty;
                using (WebResponse response = e.Response)
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)response;
                    Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
                    using (Stream strmData = response.GetResponseStream())
                    {
                        using (var reader = new StreamReader(strmData))
                        {
                            string text = reader.ReadToEnd();
                            // Trace.TraceError("Error code: {0} Details : {1}", httpResponse.StatusCode, text);
                            //throw new Exception(text);
                            _retError = text;
                        }
                    }
                    return _retError;
                }
                throw new Exception("Error Occured " + e.Message);
            }

            System.IO.StreamReader sr = new System.IO.StreamReader(resp.GetResponseStream());
            string respString = sr.ReadToEnd().Trim();
            return respString;
        }
        public static string callAPI( string clientID, string clientSecret, string resource, string tokenURL, string postAPIURL, string jsonDataString,string IsCustomer="N")
        {
            string returnVal = string.Empty;
            //GetAccessToken to call F&O API
            //var tokenFnO = GetAccessToken(clientID, clientSecret, resource, tokenURL);
            var tokenFnO = GetFnOToken(clientID, clientSecret, resource, tokenURL);
            
            //ParentInvoiceData invoiceDataObj = new ParentInvoiceData();
            //List<InvoiceData> invoiceDatas = new List<InvoiceData>();

            if (tokenFnO != null)
            {
                var jsonData = "{\n  \"dataAreaId\": \"usmf\",\n  \"OrganizationName\": \"Al Mazhar Industries\",\n  \"CustomerAccount\": \"C00166\",\n  \"CustomerGroupId\": \"30\",\n  \"NameAlias\": \"Al Mazhar Industries\",\n  \"AddressStreet\": \"1 Sheikh Mohammed bin Rashid Blvd\",\n  \"AddressDescription\": \"Al Mazhar Industries\",\n  \"PrimaryContactEmailDescription\": \"\",\n  \"PrimaryContactEmail\": \"raj.mathur@gomail.com\",\n  \"PrimaryContactPhone\": \"9820989890\",\n  \"PaymentTerms\": \"\",\n  \"OnHoldStatus\": \"All\",\n  \"PWC_RelationshipType\": \"2\",\n  \"PWC_Owener\": \"D365 CRM Admin\",\n  \"SalesCurrencyCode\": \"AED\",\n  \"AddressCity\": \"Dubai\",\n  \"AddressState\": \"\",\n  \"AddressZipCode\": \"1234567889\",\n  \"AddressCountryRegionId\": \"UAE\"\n}"; ;
                //var jsonData = jsonDataString;
  
                Console.WriteLine($"Request body for API: {jsonData}");

                //Call FnO API to get Invoice details & Customer Status.
                //var getTabResponse = GetWebResponse(new Uri(postAPIURL), tokenFnO, "application/json", "POST", jsonData);
                var getTabResponse = GetWebResponse(new Uri(postAPIURL), tokenFnO, "application/json", "POST", jsonData);
                if (getTabResponse != null)
                {
                    var data = (JObject)JsonConvert.DeserializeObject(getTabResponse);

                    if (IsCustomer == "Y")
                    {
                        if (data.ContainsKey("PartyNumber"))
                        {
                            returnVal = data["PartyNumber"].Value<string>();
                        }
                        else
                        {
                            int firstStringPosition = data.ToString().IndexOf("Infolog: Info:");
                            int secondStringPosition = data.ToString().IndexOf("Microsoft.Dynamics.");
                            string stringBetweenTwoStrings = data.ToString().Substring(firstStringPosition, secondStringPosition - firstStringPosition - 23);
                            returnVal = stringBetweenTwoStrings;
                        }
                    }
                    //var desrialisedInvoiceDate = JsonConvert.DeserializeObject(getTabResponse);
                    using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(getTabResponse)))
                    {
                        // Deserialization from JSON  
                        // DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(List<InvoiceData>));
                        // invoiceDatas = (List<InvoiceData>)deserializer.ReadObject(ms);
                        // Console.WriteLine($"Deserialized Object Response: {invoiceDatas}");
                    }

                    //foreach (var item in invoiceDatas)
                    //{
                    //    Console.WriteLine(item);
                    //    //string InvoiceID = item[]
                    //}
                }
            }
            return returnVal;
        }
        #endregion
    }
}
