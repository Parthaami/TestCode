﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace PluginCrmERPIntegration
{
    public static class Data
    {

        /// <summary>
        /// GetApiConfigurations
        /// </summary>
        /// <param name="service"></param>
        /// <param name="objSchemaMappingClass"></param>
        /// <returns>List<dynamic></returns>
        public static EntityCollection GetApiConfigurations(IOrganizationService service, object objSchemaMappingClass)
        {
            try
            {
                var query = new QueryExpression("mah_crmfoapiintegrationsetting");
                query.ColumnSet = new ColumnSet();               
                List<ApiConfigSettings> ObjList = new List<ApiConfigSettings>();
                PropertyInfo[] ClasProperties = objSchemaMappingClass.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    if (Attribute.GetCustomAttributesData().Count > 0)
                    {
                        var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                        if (EntityAttributeCollection.Count > 0)
                        {
                            AttributeName = "" + EntityAttributeCollection[0].Value;
                        }
                    }
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                EntityCollection ec = service.RetrieveMultiple(query);
                return ec;
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        /// <summary>
        /// JsonGetAccount
        /// </summary>
        /// <param name="service"></param>
        /// <param name="AccountId"></param>
        /// <param name="objSchemaMappingClass"></param>
        /// <returns>Json String</returns>
        public static string JsonGetAccount(IOrganizationService service, Guid AccountId, ref Account _OutputDataModel)
        {
            try
            {
                var query = new QueryExpression("account");
                query.ColumnSet = new ColumnSet();
               // Account _OutputDataModel = new Account();
                PropertyInfo[] ClasProperties = _OutputDataModel.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    if (Attribute.GetCustomAttributesData().Count > 0)
                    {
                        var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                        if (EntityAttributeCollection.Count > 0)
                        {
                            AttributeName = "" + EntityAttributeCollection[0].Value;
                        }
                    }
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("accountid", ConditionOperator.Equal, AccountId);
                EntityCollection ec = service.RetrieveMultiple(query);                
                string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel);
                return JSON_Output;
            }
            catch(Exception ex)
            {
               
            }
            return "";
        }

        /// <summary>
        /// JsonGetContact
        /// </summary>
        /// <param name="service"></param>
        /// <param name="AccountId"></param>
        /// <param name="ContactID"></param>
        /// <param name="objSchemaMappingClass"></param>
        /// <returns>Json String</returns>
        public static string JsonGetContact(IOrganizationService service, Guid AccountId)
        {
            try
            {
                var query = new QueryExpression("contact");
                query.ColumnSet = new ColumnSet();
                Contact _OutputDataModel = new Contact();
                PropertyInfo[] ClasProperties = _OutputDataModel.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    if (Attribute.GetCustomAttributesData().Count > 0)
                    {
                        var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                        if (EntityAttributeCollection.Count > 0)
                        {
                            AttributeName = "" + EntityAttributeCollection[0].Value;
                        }
                    }
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("parentcustomerid", ConditionOperator.Equal, AccountId);
                
                //query.Criteria.AddCondition("contactid", ConditionOperator.Equal, ContactID);

                //query.LinkEntities.Add(new LinkEntity("contact", "account", "primarycontactid", "contactid", JoinOperator.Inner));
                //query.LinkEntities[0].EntityAlias = "Acct";

                EntityCollection ec = service.RetrieveMultiple(query);               
                string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel);
                return JSON_Output;
            }
            catch (Exception ex)
            {

            }
            return "";
        }

        /// <summary>
        /// JsonGetQuote
        /// </summary>
        /// <param name="service"></param>
        /// <param name="QuoteID"></param>
        /// <returns></returns>
        public static string JsonGetQuote(IOrganizationService service, Guid QuoteID, ref Quote _OutputDataModel)
        {
            try
            {
                var query = new QueryExpression("quote");
                query.ColumnSet = new ColumnSet();
                PropertyInfo[] ClasProperties = _OutputDataModel.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    if (Attribute.GetCustomAttributesData().Count > 0)
                    {
                        var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                        if (EntityAttributeCollection.Count > 0)
                        {
                            AttributeName = "" + EntityAttributeCollection[0].Value;
                        }
                    }
                    if (!AttributeName.Contains("."))
                    {
                        query.ColumnSet.Columns.Add(AttributeName);
                    }
                }
                //LinkEntity _businessunit = new LinkEntity("quote", "businessunit", "owningbusinessunit", "businessunitid", JoinOperator.Inner);
                //_businessunit.EntityAlias = "bu";
                //_businessunit.Columns.AddColumn("mk_legalentity");
                //query.LinkEntities.Add(_businessunit);




                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, QuoteID);

                query.LinkEntities.Add(new LinkEntity("quote", "businessunit", "owningbusinessunit", "businessunitid", JoinOperator.Inner));
                query.LinkEntities[0].Columns.AddColumns("mk_legalentity");
                query.LinkEntities[0].EntityAlias = "bu";


                EntityCollection ec = service.RetrieveMultiple(query);
                string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel);
                return JSON_Output;
            }
            catch (Exception ex)
            {

            }
            return "";
        }

        /// <summary>
        /// JsonGetQuoteDetail
        /// </summary>
        /// <param name="service"></param>
        /// <param name="QuoteID"></param>
        /// <returns></returns>
        public static string JsonGetQuoteDetail(IOrganizationService service, Guid QuoteID)
        {
            try
            {
                var query = new QueryExpression("quotedetail");
                query.ColumnSet = new ColumnSet();
                QuoteDetail _OutputDataModel = new QuoteDetail();
                PropertyInfo[] ClasProperties = _OutputDataModel.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    if (Attribute.GetCustomAttributesData().Count > 0)
                    {
                        var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                        if (EntityAttributeCollection.Count > 0)
                        {
                            AttributeName = "" + EntityAttributeCollection[0].Value;
                        }
                    }
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, QuoteID);
                EntityCollection ec = service.RetrieveMultiple(query);
                string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel);
                return JSON_Output;
            }
            catch (Exception ex)
            {

            }
            return "";
        }

    }
}
