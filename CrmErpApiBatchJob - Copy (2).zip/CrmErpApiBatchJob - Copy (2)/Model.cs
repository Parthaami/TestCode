﻿using Newtonsoft.Json;

namespace PluginCrmERPIntegration
{

    public class ApiConfigSettings
    {
        [JsonProperty("mah_name")]
        public string ApiName { get; set; }
        [JsonProperty("mah_apiurl")]
        public string ApiURL { get; set; }
        [JsonProperty("mah_method")]
        public string MethodType { get; set; }
        [JsonProperty("mah_key")]
        public string ApiKey { get; set; }
        //[JsonProperty("new_authenticationtype")]
        //public string AuthenticationType { get; set; }
    }

    public class Account
    {
        [JsonProperty("name")]
        public string CustomerAccount { get; set; }
        [JsonProperty("mah_customerid")]
        public string CustomerID { get; set; }
        //[JsonProperty("")]
        //public string CustomerGroup { get; set; }
        [JsonProperty("transactioncurrencyid")]
        public string Currency { get; set; }
        [JsonProperty("name")]
        public string  Name { get; set; }
        [JsonProperty("address1_composite")]
        public string StreetAddress { get; set; }
        [JsonProperty("address1_city")]
        public string City { get; set; }
        [JsonProperty("address1_stateorprovince")]
        public string State { get; set; }
        [JsonProperty("address1_postalcode")]
        public string Pincode { get; set; }
        [JsonProperty("address1_country")]
        public string Country { get; set; }
        //[JsonProperty("")]
        //public string Address Description { get; set; }
        //[JsonProperty("")]
        //public string Descreption { get; set; }
        [JsonProperty("emailaddress1")]
        public string Email { get; set; }
        [JsonProperty("telephone1")]
        public string Phone { get; set; }
        [JsonProperty("paymenttermscode")]
        public string TermsofPayment { get; set; }
        //[JsonProperty("")]
        //public string Customer Hold Flag { get; set; }
        [JsonProperty("customertypecode")]
        public string RelationshipType { get; set; }

        //Refernce 
        [JsonProperty("accountid")]
        public string AccountGUID { get; set; }
        [JsonProperty("parentaccountid")]
        public string ParentAccountID { get; set; }
        [JsonProperty("primarycontactid")]
        public string PrimaryContactId { get; set; }
        [JsonProperty("msdyn_billingaccount")]
        public string BillingAccount { get; set; }
        [JsonProperty("masterid")]
        public string MasterID { get; set; }
    }

    public class Quote
    {
        [JsonProperty("quoteid")]
        public string QuoteID { get; set; }
        [JsonProperty("mah_quotationnumber")]
        public string QuotationNumber { get; set; }
        [JsonProperty("revisionnumber")]
        public string RevisionID { get; set; }
        [JsonProperty("bu.mk_legalentity")]
        public string LegalEntity { get; set; }      //=>  MAP BU Entity (Owner ID pass to BU), atrribute => mk_legalentity
        //[JsonProperty("")]
        //public string Quotation Type { get; set; }
        [JsonProperty("ownerid")]
        public string Owner { get; set; }
        [JsonProperty("effectivefrom")]
        public string EffectiveFrom { get; set; }
        [JsonProperty("effectiveto")]
        public string EffectiveTo { get; set; }
        [JsonProperty("pwc_projectname")]
        public string ProjectName { get; set; }
        [JsonProperty("opportunityid")]
        public string Opportunity { get; set; }       
        [JsonProperty("customerid")]
        public string PotentialCustomer { get; set; }   // Accounnt ID
        [JsonProperty("mah_contractor")]
        public string Contractor { get; set; }
        [JsonProperty("transactioncurrencyid")]
        public string Currency { get; set; }
        [JsonProperty("mah_quoteremarks")]
        public string QuoteRemarks { get; set; }
        [JsonProperty("mah_paymentterms")]
        public string PaymentTermsPercentage { get; set; }
        [JsonProperty("mah_warranty")]
        public string Warranty { get; set; }
        [JsonProperty("mah_cancellationcharge")]
        public string CancellationChargePercentage { get; set; }
        [JsonProperty("mah_scopeofwork")]
        public string Scopeofwork { get; set; }
        [JsonProperty("totallineitemamount")]
        public string SubTotal { get; set; }
        [JsonProperty("discountpercentage")]
        public string  DiscountPercentage { get; set; }
        [JsonProperty("discountamount")]
        public string  Discount { get; set; }
        [JsonProperty("totalamountlessfreight")]
        public string PreFreightAmount { get; set; }
        [JsonProperty("freightamount")]
        public string  FreightAmount { get; set; }
        [JsonProperty("mah_vattrn")]
        public string VAT { get; set; }
        [JsonProperty("totalamount")]
        public string Total { get; set; }
        [JsonProperty("mah_lpo")]
        public string LPONumber { get; set; }
        //[JsonProperty("")]
        //public string LPO Amount { get; set; }
        //[JsonProperty("")]
        //public string LPO Date { get; set; }
        [JsonProperty("billto_line1")]
        public string BillToStreet1 { get; set; }
        [JsonProperty("billto_line2")]
        public string BillToStreet2 { get; set; }
        [JsonProperty("billto_line3")]
        public string BillToStreet3 { get; set; }
        [JsonProperty("billto_city")]
        public string BillToCity { get; set; }
        [JsonProperty("billto_stateorprovince")]
        public string BillToStateProvince { get; set; }
        [JsonProperty("billto_stateorprovince")]
        public string BillToZIPPostalCode { get; set; }
        [JsonProperty("billto_country")]
        public string BillToCountryRegion { get; set; }
        [JsonProperty("billto_name")]
        string BillToName { get; set; }
        [JsonProperty("billto_telephone")]
        public string BillToPhone { get; set; }
        [JsonProperty("emailaddress")]
        public string BillToEmailAddress { get; set; }
        [JsonProperty("willcall")]
        public string ShipTo { get; set; }
        [JsonProperty("shipto_line1")]
        public string ShipToStreet1 { get; set; }
        [JsonProperty("shipto_line2")]
        public string ShipToStreet2 { get; set; }
        [JsonProperty("shipto_line3")]
        public string ShipToStreet3 { get; set; }
        [JsonProperty("shipto_city")]
        public string ShipToCity { get; set; }
        [JsonProperty("shipto_stateorprovince")]
        public string ShipToStateProvince { get; set; }
        [JsonProperty("shipto_postalcode")]
        public string ShipToZIPPostalCode { get; set; }
        [JsonProperty("shipto_country")]
        public string ShipToCountryRegion { get; set; }

        //Reference 
        //[JsonProperty("contactid")]
        //public string ContactID { get; set; }
        //[JsonProperty("msdyn_account")]
        //public string MsDynAccount { get; set; }
        //[JsonProperty("accountid")]
        //public string AccountID { get; set; }
        //[JsonProperty("mah_contractor")]
        //public string MahContractor { get; set; }
        //[JsonProperty("pwc_contractor")]
        //public string PwcContractor { get; set; }
    }

    public class QuoteDetail
    {
        [JsonProperty("productdescription")]
        public string ProductWriteInProduct { get; set; }
        [JsonProperty("isproductoverridden")]
        public string WriteIn { get; set; }
        [JsonProperty("ispriceoverridden")]
        public string Pricing { get; set; }
        [JsonProperty("priceperunit")]
        public string PricePerUnit { get; set; }
        [JsonProperty("quantity")]
        public string Quantity { get; set; }
        [JsonProperty("baseamount")]
        public string Amount { get; set; }
        [JsonProperty("manualdiscountamount")]
        public string ManualDiscount { get; set; }
        [JsonProperty("tax")]
        public string Tax { get; set; }
        [JsonProperty("extendedamount")]
        public string ExtendedAmount { get; set; }

        //Reference 
        [JsonProperty("quotedetailid")]
        public string QuoteDetailId { get; set; }
        [JsonProperty("parentbundleidref")]
        public string ParentBundleIdRef { get; set; }
        [JsonProperty("quoteid")]
        public string QuoteID { get; set; }
        [JsonProperty("msdyn_serviceaccount")]
        public string MsDynServiceAccount  { get; set; }
    }

    public class Contact
    {
        [JsonProperty("address1_primarycontactname")]
        public string ContactName { get; set; }
        [JsonProperty("parentcustomerid")]
        public string Accountid { get; set; }  // Related Account 
        [JsonProperty("telephone1")]
        public string BusinessPhone { get; set; }
        [JsonProperty("address1_composite")]
        public string Address { get; set; }
        [JsonProperty("ownerid")]
        public string Owner { get; set; }
        [JsonProperty("mobilephone")]
        public string MobileNo { get; set; }
        [JsonProperty("emailaddress1")]
        public string Emailid { get; set; }

        //Reference
        //[JsonProperty("contactid")]
        //public string ContactID { get; set; }
        //[JsonProperty("parentcontactid")]
        //public string ParentContactID { get; set; }
        ////[JsonProperty("pwcmanager")]
        ////public string PwcManager { get; set; }
        //[JsonProperty("masterid")]
        //public string MasterID { get; set; }
        //[JsonProperty("accountid")]
        //public string AccountID { get; set; }
    }

}
