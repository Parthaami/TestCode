﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.WebServiceClient;
using Microsoft.Xrm.Tooling.Connector;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Reflection;
using System.ServiceModel.Description;

namespace PluginCrmERPIntegration
{
    public static class Utilities
    {

        /// <summary>
        /// ConnectD35OnlineUsingOrgSvc
        /// </summary>
        /// <returns></returns>
        public static IOrganizationService ConnectD35OnlineUsingOrgSvc()
        {


            //var username = " D365CRMAdmin@mahykhoory.com";
            //var Password = "Dubai@000MRC";
            //var AppId = "8705ecd0-e489-4d02-827e-e471b5a6f6eb";
            //var url = "https://mahykhoorysandbox.crm4.dynamics.com/";
            //var RedirectUri = "api://8705ecd0-e489-4d02-827e-e471b5a6f6eb";
            //string conn = $@"Url = {url};
            //                AuthType = OAuth;
            //                UserName = {username};
            //                Password = {Password};
            //                AppId = {AppId}
            //                RedirectUri = {RedirectUri}
            //                LoginPrompt=Auto;
            //                RequireNewInstance = True";

            //CrmServiceClient svc = null;
            //try
            //{

            //string authType = "OAuth";
            //string userName = "D365CRMAdmin@mahykhoory.com";
            //string password = "Dubai@000MRC";
            //string url = "https://mahykhoorysandbox.crm4.dynamics.com/";
            //string appId = "8705ecd0-e489-4d02-827e-e471b5a6f6eb";
            //string reDirectURI = "api://8705ecd0-e489-4d02-827e-e471b5a6f6eb";
            //string loginPrompt = "Auto";


            //var username = "D365CRMAdmin@mahykhoory.com";
            //var Password = "Dubai@000MRC";
            ////var AppId = "8705ecd0-e489-4d02-827e-e471b5a6f6eb";
            //var url = "https://mahykhoorysandbox.crm4.dynamics.com/";
            ////var RedirectUri = "https://mahkhoorydev.api.crm4.dynamics.com/api/data/v9.2/";
            //string ConnectionString = $@"
            //Url = {url};
            //AuthType = OAuth;
            //UserName = {username};
            //Password = {Password};
            //AppId = 8705ecd0-e489-4d02-827e-e471b5a6f6eb;
            //RedirectUri = api://8705ecd0-e489-4d02-827e-e471b5a6f6eb;
            //LoginPrompt=Auto;
            //RequireNewInstance = True";

            //string ConnectionString = string.Format("AuthType = {0};Username = {1};Password = {2}; Url = {3}; AppId={4}; RedirectUri={5};LoginPrompt={6}",
            //                                        authType, userName, password, url, appId, reDirectURI, loginPrompt);

            IOrganizationService organizationService1 = null;
            //String ConnectionString = ConfigurationManager.AppSettings["MyCDSServer"].ToString();

            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            //ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            //var connection = new CrmServiceClient(ConnectionString);

            //if (connection.IsReady)
            //{
            //    organizationService1 = connection.OrganizationWebProxyClient != null ? connection.OrganizationWebProxyClient : (IOrganizationService)connection.OrganizationServiceProxy;
            //}


            //if (svc.IsReady)
            //{
            //    string ss = "";
            //    //PerformCRUD(svc);
            //}

            // Client Secret

            IOrganizationService organizationService = null;
            
            //String orgUrl = ConfigurationManager.AppSettings["ServerUrl"].ToString();
               // String username = ConfigurationManager.AppSettings["username"].ToString();
                //String password = ConfigurationManager.AppSettings["password"].ToString();
                try
                {
                // ClientCredentials clientCredentials = new ClientCredentials();
                // clientCredentials.UserName.UserName = username;
                //clientCredentials.UserName.Password = password;

                // For Dynamics 365 Customer Engagement V9.X, set Security Protocol as TLS12
                // ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                //string crmConnectionString = "AuthType='Office365'; Url='" + orgUrl + "'; Username='" + username + "'; Password='" + username + "';";

                //CrmServiceClient conn   = new CrmServiceClient(crmConnectionString);


                // organizationService = (IOrganizationService)conn.OrganizationWebProxyClient != null ? (IOrganizationService)conn.OrganizationWebProxyClient : (IOrganizationService)conn.OrganizationServiceProxy;


                // organizationService = (IOrganizationService)new OrganizationServiceProxy(new Uri(orgUrl), null, clientCredentials, null);

                //var pwd = ConvertToSecureString("Dubai@000MRC");
                //CrmServiceClient conn  = new CrmServiceClient("D365CRMAdmin@mahykhoory.com",pwd, "Middle East", "2f279a0cee574f72baf77f70747baf88", isOffice365:true);

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                string connectionString = "AuthType=OAuth;Url='';Username='';Password=''AppId=8705ecd0-e489-4d02-827e-e471b5a6f6eb;RedirectUri=;LoginPrompt=Never";
                CrmServiceClient conn = new CrmServiceClient(connectionString);
                organizationService = (IOrganizationService)conn.OrganizationWebProxyClient != null ? (IOrganizationService)conn.OrganizationWebProxyClient : (IOrganizationService)conn.OrganizationServiceProxy;


                if (organizationService != null)
                {
                    //Guid gOrgId = ((WhoAmIResponse)service.Execute(new WhoAmIRequest())).OrganizationId;
                    //if (gOrgId != Guid.Empty)
                    //{
                    //    Console.WriteLine("Connection Established Successfully...");
                    //}
                }
                    else
                    {
                        Console.WriteLine("Failed to Established Connection!!!");
                    }


                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception occured - " + ex.Message);
                }
                return organizationService;
                

            }

        /// <summary>
        /// CreateIOrganizationService
        /// </summary>
        /// <param name="ClientId"></param>
        /// <param name="clientSecret"></param>
        /// <param name="organizationUri"></param>
        /// <returns></returns>
        public static IOrganizationService CreateIOrganizationService()//(string ClientId, string clientSecret, string organizationUri)
        {
            string ClientId = "8705ecd0-e489-4d02-827e-e471b5a6f6eb";
            string clientSecret = "In37Q~bHXYvEJyVptGZ.j5x6fTQ198sQt.dz1";
            string organizationUri = "52.156.193.146";//"https://mahykhoorysandbox.crm4.dynamics.com";
            IOrganizationService orgService = null;

           // AuthType = Office365; Url = https://mahykhoorysandbox2.crm4.dynamics.com;Username=D365CRMAdmin@mahykhoory.com;Password=********

            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                string CrmConnectionString = "AuthType = Office365; Url = https://mahykhoorysandbox2.crm4.dynamics.com;Username=D365CRMAdmin@mahykhoory.com;Password=Dubai@000MRC";//ConfigurationManager.AppSettings["CrmConnectionString"].ToString();
                //CrmServiceClient crmConnection = new CrmServiceClient($@"AuthType=ClientSecret;url={organizationUri};ClientId={ClientId};ClientSecret={clientSecret}");
                CrmServiceClient crmConnection = new CrmServiceClient(CrmConnectionString);
                orgService = crmConnection.OrganizationWebProxyClient != null ? crmConnection.OrganizationWebProxyClient : (IOrganizationService)crmConnection.OrganizationServiceProxy;
            }
            catch (Exception ex)
            {
                throw new Exception($@"An error occured while creating organization service with exception {ex}");
            }

            return orgService;
        }

        /// <summary>
        /// ConvertToSecureString
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        private static System.Security.SecureString ConvertToSecureString(string password)
        {
            if (password == null)
                throw new ArgumentException("missing pwd");

            var securePassword = new System.Security.SecureString();
            foreach (char c in password)
                securePassword.AppendChar(c);

            securePassword.MakeReadOnly();
            return securePassword;

        }


        //S2S Authentication
        internal static OrganizationWebProxyClient GetS2SService(string hostName, string clientid, string clientsecret)
        {
            //hostName = CrmInstance;
            ClientCredential clientcred = new ClientCredential(clientid, clientsecret);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            //AuthenticationContext authenticationContext =
            // new AuthenticationContext("https://login.microsoftonline.com/{clientId}");

            AuthenticationContext authenticationContext =
    new AuthenticationContext("https://login.windows.net/common", false);

            authenticationContext.TokenCache.Clear();

            AuthenticationResult authenticationResult =
             authenticationContext.AcquireTokenAsync(hostName, clientcred).Result;
            var _service = new OrganizationWebProxyClient(new Uri($"{hostName}/xrmservices/2011/organization.svc/web?SdkClientVersion=9.0"), TimeSpan.MaxValue, false);
            _service.HeaderToken = authenticationResult.AccessToken;
            return _service;
        }

        public static string GetAccessTokenSrc(string hostName, string clientid, string clientsecret)
        {
            ClientCredential clientcred = new ClientCredential(clientid, clientsecret);
            AuthenticationContext authenticationContext =
             new AuthenticationContext("https://login.microsoftonline.com/{clientID}");

            authenticationContext.TokenCache.Clear();

            AuthenticationResult authenticationResult =
             authenticationContext.AcquireTokenAsync(hostName, clientcred).Result;

            return authenticationResult.AccessToken;
        }

        /// <summary>
        /// GetAttributeValues (Retrieve Any Type Of (Entity) Attribute Value)
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="FieldSchemaName"></param>
        /// <param name="FormattedValue"></param>
        /// <returns>Attribute Value</returns>
        private static string GetAttributeValues(Entity entity, string FieldSchemaName, bool FormattedValue = true)
        {
            if (entity.Contains(FieldSchemaName))
            {
                var EntityAttribute = entity.Attributes[FieldSchemaName];
                string AttributeTypeName = EntityAttribute.GetType().Name;

                if (AttributeTypeName.Equals("AliasedValue"))
                {
                    EntityAttribute = ((AliasedValue)entity.Attributes[FieldSchemaName]).Value;
                    AttributeTypeName = EntityAttribute.GetType().Name;
                }
                string AttributeValueGUID = "";
                string AttributeValueName = "";
                switch (AttributeTypeName)
                {
                    case "OptionSetValue":
                        OptionSetValue AttributeOptionSetValue = (OptionSetValue)EntityAttribute;
                        AttributeValueGUID = "" + AttributeOptionSetValue.Value;
                        break;
                    case "EntityReference":
                        EntityReference AttributeReference = (EntityReference)EntityAttribute;
                        AttributeValueGUID = "" + AttributeReference.Id;
                        AttributeValueName = AttributeReference.Name;
                        break;
                    case "Guid":
                        AttributeValueGUID = "" + EntityAttribute;
                        break;
                    case "Money":
                        AttributeValueName = "" + Convert.ToString(((Money)EntityAttribute).Value);
                        break;
                    case "DateTime":
                        AttributeValueName = "" + Convert.ToString(((DateTime)EntityAttribute));
                        break;
                    case "Int32":
                        AttributeValueName = "" + Convert.ToString(((Int32)EntityAttribute));
                        break;                    
                    case "String":
                        AttributeValueName = "" + Convert.ToString(((String)EntityAttribute));
                        break;
                    //case "bool":

                }
                if (FormattedValue)
                {
                    if (AttributeValueName.Trim() == "")
                        return AttributeValueGUID;
                    else
                        return AttributeValueName;
                }
                else
                {
                    return AttributeValueGUID;
                }
            }
            else
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// GetJsonArrayFromFetchXML
        /// </summary>
        /// <param name="FetchedRecordsCollection"></param>
        /// <param name="objSchemaMappingClass"></param>
        /// <returnsJSON Array As String & Populate All Field Values Of objSchemaMappingClass></returns>
        public static string GetJsonArrayFromFetchXML(
              EntityCollection FetchedRecordsCollection
            , object objSchemaMappingClass
            )
        {
            JObject ObjJSON = new JObject();
            try
            {
                if (FetchedRecordsCollection == null)
                {
                    ObjJSON.Add("message", "No Data Found!");
                    return ObjJSON.ToString();
                }
                if (FetchedRecordsCollection.Entities.Count < 1)
                {
                    ObjJSON.Add("message", "No Data Found!");
                    return ObjJSON.ToString();
                }
                else
                {
                    List<dynamic> ObjList = new List<dynamic>();
                    PropertyInfo[] ClasProperties = objSchemaMappingClass.GetType()
                                                    .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                    foreach (Entity objEntity in FetchedRecordsCollection.Entities)
                    {
                        ObjJSON = new JObject();
                        foreach (PropertyInfo Attribute in ClasProperties)
                        {
                            string AttributeName = Attribute.Name;
                            string EntityAttributeName = Attribute.Name;
                            if (Attribute.GetCustomAttributesData().Count > 0)
                            {
                                var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                                if (EntityAttributeCollection.Count > 0)
                                {
                                    EntityAttributeName = "" + EntityAttributeCollection[0].Value;
                                }
                            }
                            bool isFormattedValue = EntityAttributeName == "customerid" ? false : true;
                            string EntityAttributeValue = "" + GetAttributeValues(objEntity, EntityAttributeName, isFormattedValue);
                            Attribute.SetMethod.Invoke(objSchemaMappingClass, new object[] { EntityAttributeValue });
                            //Attribute.GetValue(objSchemaMappingClass, null);
                            ObjJSON.Add(AttributeName, EntityAttributeValue);
                        }

                        ObjList.Add(JsonConvert.DeserializeObject<dynamic>(ObjJSON.ToString()));
                    }

                    return JsonConvert.SerializeObject(ObjList, Formatting.Indented);
                }
            }
            catch (Exception ex)
            {
                ObjJSON.Add("Error", ex.Message);
                return ObjJSON.ToString();
            }

        }


        /// <summary>
        /// GetAPIResult
        /// </summary>
        /// <param name="strBaseAddress"></param>
        /// <param name="AccessTypeHeader"></param>
        /// <param name="strAccessToken"></param>
        /// <param name="strMethodName"></param>
        /// <param name="strJsonInput"></param>
        /// <param name="responseObject"></param>
        /// <param name="strResult"></param>
        /// <param name="TotalRecords"></param>
        /// <param name="Exception"></param>
        /// <returns></returns>
        public static string GetAPIResult(string strBaseAddress,
                                     string AccessTypeHeader,
                                     string strAccessToken,
                                     string strJsonInput
                                     )
        {
            MemoryStream ResponseStream = new MemoryStream();
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3
                | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                HttpWebRequest postRequest = (HttpWebRequest)WebRequest.Create(strBaseAddress);
                postRequest.ContentType = "application/json";
                postRequest.Method = "POST";
                postRequest.Timeout = 50000;
                postRequest.Headers.Add(AccessTypeHeader, strAccessToken);
                StreamWriter requeststream = new StreamWriter(postRequest.GetRequestStream());
                dynamic inputData = JsonConvert.DeserializeObject(strJsonInput);
                var json = JsonConvert.SerializeObject(inputData);
                requeststream.Write(json);
                requeststream.Close();
                try
                {
                     HttpWebResponse getResponse = (HttpWebResponse)postRequest.GetResponse();
                    return "" + getResponse;
                }
                catch (WebException ex)
                {
                    return "" + ex.Response + Environment.NewLine + ex.Message;
                }
                
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

            //return string.Empty;
        }


        /// <summary>
        /// CreateLog
        /// </summary>
        /// <param name="requestObject"></param>
        /// <param name="ApiURL"></param>
        /// <param name="response"></param>
        /// <param name="Status"></param>
        /// <param name="errorMessage"></param>
        /// <param name="_service"></param>
        public static void CreateLog(string requestObject, String ApiURL, String response, int Status, string errorMessage, IOrganizationService _service)
        {
            try
            {
                var entity = new Entity("mah_crmfoapiintegrationlog");
                entity.Attributes["mah_requestbody"] = requestObject;
                if (!String.IsNullOrEmpty(errorMessage))
                {
                    entity.Attributes["mah_errormessage"] = errorMessage;
                }

                entity.Attributes["mah_issuccess"] = new OptionSetValue(Status);
                entity.Attributes["mah_apiurl"] = ApiURL;
                entity.Attributes["mah_response"] = response;
                _service.Create(entity);

            }
            catch (Exception ex)
            {
                //return Guid.Empty;
            }
        }


    }
}
