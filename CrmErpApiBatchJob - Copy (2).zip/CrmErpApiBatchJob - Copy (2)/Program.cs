
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Net;
using System.ServiceModel.Description;
using System.Linq;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;
using Microsoft.Xrm.Sdk.WebServiceClient;

namespace PluginCrmERPIntegration
{

    class Program
    {

        static void Main(string[] args)
        {
            //Create IOrgannization Service Object
            //IOrganizationService service = Utilities.ConnectD35OnlineUsingOrgSvc();

            IOrganizationService service = Utilities.CreateIOrganizationService();
           // OrganizationWebProxyClient service = Utilities.GetS2SService("mahykhoorysandbox.crm4.dynamics.com", "8705ecd0-e489-4d02-827e-e471b5a6f6eb", "In37Q~bHXYvEJyVptGZ.j5x6fTQ198sQt.dz1");

            
            if (service != null)
            {

                Guid QuoteID = Guid.Parse("{73029632-b6ae-ec11-9840-000d3ab85977}");               
                //string StatusCode_Won = "4";
                //EntityCollection ecQuote = RetrivedAllQuote.RetrieveAllWonQuote(service, StatusCode_Won);

                //if (ecQuote.Entities.Count > 0)
                //{
                //    foreach (Entity _QuoteVal in ecQuote.Entities)
                //    {
                //        QuoteID = (Guid)_QuoteVal["quoteid"];

                        Quote _ModelQuote = new Quote();
                        Account _ModelAccount = new Account();
                        string JsonQuote = Data.JsonGetQuote(service, QuoteID, ref _ModelQuote);

                        string JsonQuoteDeatil = Data.JsonGetQuoteDetail(service, QuoteID);

                        Guid _accountid = Guid.Parse("" + _ModelQuote.PotentialCustomer);
                        string JsonAccount = Data.JsonGetAccount(service, _accountid, ref _ModelAccount);

                        Guid _parentAccountid = Guid.Parse("" + _ModelAccount.AccountGUID);
                        string JsonContact = Data.JsonGetContact(service, _parentAccountid);

                        ApiConfigSettings _apiConfig = new ApiConfigSettings();

                      EntityCollection listApiConfigs = Data.GetApiConfigurations(service, _apiConfig);

                        var json = new JavaScriptSerializer().Serialize(listApiConfigs);


                        foreach (Entity _ApiConfig in listApiConfigs.Entities)
                        {
                            string Apiname = (string)_ApiConfig["ApiName"];
                            string ApiURL = (string)_ApiConfig["ApiURL"];
                            string ApiKey = (string)_ApiConfig["ApiKey"];
                            string AuthenticationType = "OAUTH2.0";//_ApiConfig.AuthenticationType;

                            Apiname = "";
                            ApiURL = "https://mkdeveloper304448fae11374188devaos.axcloud.dynamics.com/api/services/PWC_CEAPI/PWC_WarrantyService/Invoicedata";
                            ApiKey = "";
                            AuthenticationType = "OAUTH2.0";//_ApiConfig.AuthenticationType;

                            string ApiExecutionResult = "";
                            if (Apiname == "ErpAccountAPI")
                            {
                                ApiExecutionResult = Utilities.GetAPIResult(ApiURL, AuthenticationType, ApiKey, JsonAccount);
                                
                                //Yes => 809880000   , No => 809880001
                                Utilities.CreateLog(JsonQuoteDeatil, ApiURL, ApiExecutionResult, 809880000, "", service);
                            }
                            if (Apiname == "ErpContactAPI")
                            {
                                ApiExecutionResult = Utilities.GetAPIResult(ApiURL, AuthenticationType, ApiKey, JsonContact);
                                
                                //Yes => 809880000   , No => 809880001
                                Utilities.CreateLog(JsonQuoteDeatil, ApiURL, ApiExecutionResult, 809880000, "", service);
                            }
                            if (Apiname == "ErpQuoteAPI")
                            {
                                ApiExecutionResult = Utilities.GetAPIResult(ApiURL, AuthenticationType, ApiKey, JsonQuote);
                               
                                //Yes => 809880000   , No => 809880001
                                Utilities.CreateLog(JsonQuoteDeatil, ApiURL, ApiExecutionResult, 809880000, "", service);
                            }
                            if (Apiname == "ErpQuoteProductApi")
                            {
                                ApiExecutionResult = Utilities.GetAPIResult(ApiURL, AuthenticationType, ApiKey, JsonQuoteDeatil);
                                
                                //Yes => 809880000   , No => 809880001
                                Utilities.CreateLog(JsonQuoteDeatil, ApiURL, ApiExecutionResult, 809880000, "", service);

                            }
                        }



                //    }
                //}





                Console.ReadLine();
            }



        }


    }
}
