﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PluginCrmERPIntegration
{
    public static class RetrivedAllQuote
    {

        public  static EntityCollection  RetrieveAllWonQuote(IOrganizationService _service, string StatusCode_Won)
        {
            //var originVal = GetValueOf(origin);
            EntityCollection ec;
            string RetVal = String.Empty;
            //string StatusCode_Won = "4";
            try
            {
                QueryExpression qe = new QueryExpression();
                qe.EntityName = "quote";
                //qe.ColumnSet.AllColumns = true;
                qe.ColumnSet = new ColumnSet
                    (
                "quoteid",
                "mah_quotationnumber",
                "revisionnumber",
                //"bu.mk_legalentity",
                "ownerid",
                "effectivefrom",
                "effectiveto",
                "pwc_projectname",
                "opportunityid",
                "customerid",
                "mah_contractor",
                "transactioncurrencyid",
                "mah_quoteremarks",
                "mah_paymentterms",
                "mah_warranty",
                "mah_cancellationcharge",
                "mah_scopeofwork",
                "totallineitemamount",
                "discountpercentage",
                "discountamount",
                "totalamountlessfreight",
                "freightamount",
                "mah_vattrn",
                "totalamount",
                "mah_lpo",
                "billto_line1",
                "billto_line2",
                "billto_line3",
                "billto_city",
                "billto_stateorprovince",
                "billto_stateorprovince",
                "billto_country",
                "billto_name",
                "billto_telephone",
                "emailaddress",
                "willcall",
                "shipto_line1",
                "shipto_line2",
                "shipto_line3",
                "shipto_city",
                "shipto_stateorprovince",
                "shipto_postalcode",
                "shipto_country"
                );



                qe.NoLock = true;
                qe.Criteria = new FilterExpression
                {
                    Conditions =
                        {
                             new ConditionExpression("statuscode", ConditionOperator.Equal, Convert.ToInt32(StatusCode_Won))
                        }
                };
                // EntityCollection ec = _service.RetrieveMultiple(qe);

                 ec = _service.RetrieveMultiple(qe);
                //if (ec.Entities.Count > 0)
                //{

                //    foreach (Entity LeadsourceAD in ec.Entities)
                //    {
                //        // RetVal = LeadsourceAD["ber_lockedforad"].ToString();
                //        RetVal = ((OptionSetValue)(LeadsourceAD["ber_lockedforad"])).Value.ToString();
                //        if (RetVal == "0")
                //        {
                //            RetVal = "Yes";
                //        }
                //        else if (RetVal == "1")
                //        {
                //            RetVal = "No";
                //        }

                //    }
                //}

            }
            catch (Exception ex)
            {
                throw new Exception("Error trying to retrieve RetrieveLeadsourceAD from CRM " + ex.Message);
            }
            return ec;

        }
    }
}
